package com.app.cricketstats.config

import android.content.Context
import android.content.SharedPreferences

class AppPreferences {

    private lateinit var preferences: SharedPreferences

    //SharedPreferences variables
    private val IS_LOGIN = Pair("is_login", false)
    private val EMAIL = Pair("email", "")
    private val UUID = Pair("uuid", "")
    private val TOKEN = Pair("token","")
    private val AGE_GROUP = Pair("ageGroup","")
    private val IS_IMPERIAL = Pair("isImperial", false)
    private val PROFILE_IMAGE_URL = Pair("profileUrl","")
    private val NAME = Pair("name","")


    fun init(context: Context) {
        preferences = context.getSharedPreferences(Companion.NAME, Companion.MODE)
    }

    //an inline function to put variable and save it
    private inline fun SharedPreferences.edit(operation: (SharedPreferences.Editor) -> Unit) {
        val editor = edit()
        operation(editor)
        editor.apply()
    }

    //SharedPreferences variables getters/setters
    var isLogin: Boolean
        get() = preferences.getBoolean(IS_LOGIN.first, IS_LOGIN.second)
        set(value) = preferences.edit {
            it.putBoolean(IS_LOGIN.first, value)
        }

    var email: String
        get() = preferences.getString(EMAIL.first, EMAIL.second) ?: ""
        set(value) = preferences.edit {
            it.putString(EMAIL.first, value)
        }

    var uuid: String
        get() = preferences.getString(UUID.first, UUID.second) ?: ""
        set(value) = preferences.edit {
            it.putString(UUID.first, value)
        }

    var token: String
        get() = preferences.getString(TOKEN.first, TOKEN.second) ?: ""
        set(value) = preferences.edit {
            it.putString(TOKEN.first, value)
        }

    var ageGroup: String
        get() = preferences.getString(AGE_GROUP.first, AGE_GROUP.second) ?: ""
        set(value) = preferences.edit{
            it.putString(AGE_GROUP.first, value)
        }

    var isImperial: Boolean
        get() = preferences.getBoolean(IS_IMPERIAL.first, IS_IMPERIAL.second)
        set(value) = preferences.edit{
            it.putBoolean(IS_IMPERIAL.first, value)
        }

    var profileUrl: String
        get() = preferences.getString(PROFILE_IMAGE_URL.first, PROFILE_IMAGE_URL.second) ?: ""
        set(value) = preferences.edit{
            it.putString(PROFILE_IMAGE_URL.first, value)
        }

    var name: String
        get() = preferences.getString(NAME.first, NAME.second) ?: ""
        set(value) = preferences.edit{
            it.putString(NAME.first, value)
        }



    companion object {
        private const val NAME = "UserDetails"
        private const val MODE = Context.MODE_PRIVATE
    }

}