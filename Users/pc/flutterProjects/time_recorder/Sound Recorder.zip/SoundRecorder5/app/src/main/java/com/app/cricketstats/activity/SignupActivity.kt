package com.app.cricketstats.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Paint
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.RequiresApi
  import com.app.cricketstats.R
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.ActivitySignupBinding
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.google.gson.Gson
import com.hbb20.CountryCodePicker
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.util.regex.Pattern

class SignupActivity : AppCompatActivity(), CountryCodePicker.OnCountryChangeListener {
    lateinit var binding: ActivitySignupBinding
    private var phoneNumber: String? = ""
/*
    private val emailPattern = "^[_A-Za-z0-9-]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})\$"
*/
    private var isTermsAndConditionChacked = false
    lateinit var appPreferences: AppPreferences
    var pSharedPref: SharedPreferences? = null
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        val view = binding.root
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(view)

        binding.countryCodePicker!!.setOnCountryChangeListener(this)
        binding.countryCodeText.text = "+"+binding.countryCodePicker.selectedCountryCode.toString()
        appPreferences = AppPreferences()
        appPreferences.init(this)

        binding.btnSignup.setOnClickListener {
            if (GlobalOperation.isNetworkConnected(this)){
                register()
            }else{
                GlobalOperation.showDialog(this,"Please make sure that you are connected with network.")
            }
        }
        binding.signupTextviewToGoLoginForm.setOnClickListener {
            startActivity(Intent(this,LoginActivity::class.java))
            finish()
        }
        binding.termsAndConditon.setOnClickListener {
            if (isTermsAndConditionChacked == true){
                binding.termsAndConditon.setImageResource(R.drawable.checkblnk)
                isTermsAndConditionChacked = false
            }else{
                binding.termsAndConditon.setImageResource(R.drawable.check)
                isTermsAndConditionChacked = true
            }
        }

        binding.backBtn.setOnClickListener {
            finish()
            onBackPressed()
        }


        setUiAction()
    }

    private fun setUiAction() {
        binding.signupTextviewToGoLoginForm.setPaintFlags(binding.signupTextviewToGoLoginForm.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
        binding.termsAndConditionText.setPaintFlags(binding.termsAndConditionText.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
        pSharedPref = getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
        binding.companyNameText.text = pSharedPref?.getString("companyNameString","companyNameStringNotExist").toString().replace("\"", "");
        Log.i(TAG, "setUiAction: it is "+pSharedPref?.getString("termsAndConditionTitleString","termsAndConditionTitleStringNotExist").toString().replace("\"", ""))
        binding.termsAndConditionText.text = pSharedPref?.getString("termsAndConditionTitleString","termsAndConditionTitleStringNotExist").toString().replace("\"", "").replace("\\u0026","&")
        var termsAndConditonUrlString = pSharedPref?.getString("termsAndConditonUrlString","termsAndConditonUrlStringNotExist").toString().replace("\"", "")
        binding.termsAndConditionText.setOnClickListener {
            val intent = Intent(this, WebViewActivity::class.java)
            intent.putExtra("url", termsAndConditonUrlString )
            startActivity(intent)
        }

    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun register() {
        phoneNumber =   binding.countryCodeText.text.toString()+""+binding.phoneUser.text.toString()

        if (binding.nameUser.text.isBlank()) {
            GlobalOperation.showDialog(this,"Name can not be empty")
            binding.nameUser.requestFocus()
        }else if (binding.emailUser.text.isBlank()  || !Patterns.EMAIL_ADDRESS.matcher(binding.emailUser.text.toString()).matches()) {
            if ((!Patterns.EMAIL_ADDRESS.matcher(binding.emailUser.text.toString()).matches()) && (!binding.emailUser.text.isBlank())){
                GlobalOperation.showDialog(this,"Invalid email pattern")
                binding.emailUser.requestFocus()
            }else{
                GlobalOperation.showDialog(this,"Email can not be empty")
                binding.emailUser.requestFocus()
            }
        }else if (phoneNumber!!.isBlank() || phoneNumber!!.matches("[a-zA-Z]+".toRegex()) || phoneNumber!!.length > 14 || phoneNumber!!.length < 10){
            if (binding.phoneUser.text.isBlank()){
                GlobalOperation.showDialog(this,"Phone number can not be empty")
                binding.phoneUser.requestFocus()
            }else{
                GlobalOperation.showDialog(this, "Invalid mobile number")
                binding.phoneUser.requestFocus()
            }
        }else if ( binding.passwordUser.text.isBlank() /*|| binding.passwordUser.text.length < 8*/){
            if (binding.passwordUser.text.isBlank()){
                GlobalOperation.showDialog(this,"Please enter password")
                binding.passwordUser.requestFocus()
            }/*else{
                GlobalOperation.showDialog(this,"Passsword should be atleast 8 digit")
                binding.passwordUser.requestFocus()
            }*/
        }else if ( binding.confirmPasswordUser.text.isBlank()){
            GlobalOperation.showDialog(this,"Please enter confirm password")
            binding.confirmPasswordUser.requestFocus()
        }else if (binding.confirmPasswordUser.text.toString() != binding.passwordUser.text.toString()){
            GlobalOperation.showDialog(this,"Password and Confirm password should be same")
            binding.confirmPasswordUser.requestFocus()
        }else if (isTermsAndConditionChacked == false){
            GlobalOperation.showDialog(this,"Please check first terms and condition")
        }else{
            //   phoneNumber = "+"+phoneNumber
            /*Toast.makeText(this,"phone final phone number "+phoneNumber+" ,length "+ phoneNumber!!.length,Toast.LENGTH_SHORT).show()*/
            getRegister()
        }


    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun getRegister() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String,Any>()
        map.put("name",binding.nameUser.text.toString())
        map.put("email",binding.emailUser.text.toString())
        map.put("phoneNumber",phoneNumber.toString())
        map.put("password",binding.passwordUser.text.toString())
        map.put("isTermsAccepted",isTermsAndConditionChacked)
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.userSignup(map).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        var errorText = response.errorBody()
                        Log.i(TAG, "onResponse: error body text " + errorText)
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("SIGN_UP_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            Toast.makeText(
                                    this@SignupActivity,
                                    "user successfully has been registered.",
                                    Toast.LENGTH_LONG
                            ).show()
                            appPreferences.email = mainObject.getJSONObject("data").optString("email")
                            appPreferences.uuid = mainObject.getJSONObject("data").optString("uuid")
                            appPreferences.token = mainObject.getJSONObject("data").optString("token")
                            appPreferences.isImperial = false
                            appPreferences.name = mainObject.getJSONObject("data").optString("name")
                            binding.cpCardview.visibility = View.GONE
                            val intent = Intent(this@SignupActivity, AboutCricketStats::class.java)
                            intent.putExtra("user_id", mainObject.getJSONObject("data").optString("uuid"))
                            startActivity(intent)
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                    this@SignupActivity,
                                    "problem is " + mainObject.getString("message"),
                                    Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }


    companion object {
        private const val TAG = "SignupActivity"
    }

    override fun onCountrySelected() { binding.countryCodeText.text = "+"+""+binding.countryCodePicker.selectedCountryCode.toString()}

}


