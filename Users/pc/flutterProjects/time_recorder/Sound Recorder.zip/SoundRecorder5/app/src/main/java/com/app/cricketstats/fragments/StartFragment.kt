package com.app.cricketstats.fragments

import android.Manifest
import android.content.*
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.activity.PickerViewActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentStartBinding
import com.app.cricketstats.javacode.AudioCalculator
import com.app.cricketstats.models.*
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.app.cricketstats.viewmodels.StartViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.Type
import java.text.DecimalFormat
import kotlin.properties.Delegates


class StartFragment : Fragment(), View.OnClickListener   {
    lateinit var binding: FragmentStartBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null

    private lateinit var viewModel: StartViewModel
     private var minDB1: Double? = null
    private var maxDB1: Double? = null
    private var minFrequency1: Double? = null
    private var maxFrequency1: Double? = null
    private var minDB2: Double? = null
    private var maxDB2: Double? = null
    private var minFrequency2: Double? = null
    private var maxFrequency2: Double? = null
    private var soundDurationFromStartButton: Double? = null
     private var soundEndDuration: Double? = null

    private val RECORDER_SAMPLERATE = 41000
    private val RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_MONO
    private val RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT
    private var recorder: AudioRecord? = null
    private var recordingThread: Thread? = null
    private var isRecording = false
    private val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE
    )
    private val REQUEST_RECORD_AUDIO_PERMISSION = 200
    private var filePath: String? = null
    var isRecordingStart: Boolean = false

     private var option1 by Delegates.notNull<Int>()
    private var option2 by Delegates.notNull<Double>()
    private var option3 by Delegates.notNull<Double>()
    private var option5 by Delegates.notNull<Double>()


    private var doNotGoInFirst = false
    private var doNotGoInSecond = false
    private var timeAfterSound1Recorded: Long = 0

    var output1 = 0.0
    var output2 = 0.0
    var output3 = 0.0
    var output4 = 0.0
    val dec = DecimalFormat("0.00")

    var gson: Gson? = null

    private var outputs1 = HashSet<SumarryOutput1DataClass>()
    private var outputs2 = HashSet<SumarryOutput2DataClass>()
    private var outputs3 = HashSet<SumarryOutput3DataClass>()
    private var optionBox6 = ArrayList<String>()
     var optionId6OptionHashSet = HashSet<OptionDataClass>()
     private var value = 0

    private var startTimeStamp = ""
    var firstPeakTimeStamp = ""
    var secondPeakTimeStamp = ""

    var selectedShotType = ""
    private var startTimeMillis: Long = 0
    private var millisInFuture: Long = 0

    val arrayListOfSounds = arrayListOf<ArrayList<Double>>(ArrayList(),ArrayList())


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentStartBinding.inflate(inflater, container, false)
        value += 1
        if (value > 1){
            binding.allSummaryScrollview.visibility = View.VISIBLE
        }else{
            binding.allSummaryScrollview.visibility = View.GONE
        }
        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        if (GlobalOperation.isNetworkConnected(mContext)){
            setUiAction()
        }else{
            GlobalOperation.showDialog(
                    mContext,
                    "Please make sure that you are connected with network."
            )
        }
         viewModel = ViewModelProvider(this).get(StartViewModel::class.java)
        /*viewModel.maxDB.observe(viewLifecycleOwner, Observer {
            binding.maxDbValue.text = it
        })

        viewModel.heighest.observe(viewLifecycleOwner, Observer {
            binding.heighestDb.text = it.toString()
        })

        viewModel.frequency.observe(viewLifecycleOwner, Observer {
            binding.frequency.text = it.toString()
        })*/
        binding.companyNameText.text =  getString(R.string.cricket_stats)

        ActivityCompat.requestPermissions(requireActivity(), permissions, REQUEST_RECORD_AUDIO_PERMISSION)
        setUiAction()
        setOnClickListener()

        if (savedInstanceState != null)
        {
            setAllDataAfterConfigurationChang()
        }

        LocalBroadcastManager.getInstance(requireContext()).registerReceiver(mMessageReceiver, IntentFilter("custom-event-name"))


        return binding.root
    }

    private fun setOnClickListener() {
        binding.backBtn.setOnClickListener(this)
         binding.recoderStartAndStop.setOnClickListener(this)
        binding.summary1.setOnClickListener(this)
        binding.summary2.setOnClickListener(this)
        binding.summary3.setOnClickListener(this)
        binding.summary4.setOnClickListener(this)
        binding.btnUploadData.setOnClickListener(this)
    }

    private fun setAllDataAfterConfigurationChang() {
        outputs1 = viewModel.getOutputs1Data()
        outputs2 = viewModel.getOutputs2Data()
        outputs3 = viewModel.getOutputs3Data()
        output1 = viewModel.getOutput1()
        output2 = viewModel.getOutput2()
        output3 = viewModel.getOutput3()
        output4 = viewModel.getOutput4()
        binding.allSummaryScrollview.visibility = View.VISIBLE
        if ((activity as MainActivity).isOutput3Visible) {
            binding.summary3View.visibility = View.VISIBLE
        } else {
            binding.summary3View.visibility = View.GONE
        }
        binding.output1DbTextview.text = output1.toString()
        binding.output2DbTextview.text = output2.toString()
        binding.output3DbTextview.text = output3.toString()
        binding.output4DbTextview.text = output4.toString()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)
        setAllOptionsValue()
        Log.i(TAG, "setUiAction: abcdefeg "+appPreferences.isImperial)
        setUnit()
        getHasSetToCheckCondtionOfAudio()
        if (!(activity as MainActivity).dataRecorded){
            /*binding.allSummaryScrollview.visibility = View.GONE*/
        }else{
            binding.allSummaryScrollview.visibility = View.VISIBLE
            if ((activity as MainActivity).isOutput3Visible) {
                binding.summary3View.visibility = View.VISIBLE
            } else {
                binding.summary3View.visibility = View.GONE
            }
        }

         appPreferences = AppPreferences()
        appPreferences.init(mContext!!)
        getAllOptionForOptionBox6()
     }




    private fun setAllOptionsValue() {
        val optionId1DataClassObjString = pSharedPref?.getString("optionId1DataClassObjString", "optionId1DataClassObjStringNotExist")
        val optionId1DataClassObj: OptionId1DataClass = Gson().fromJson(optionId1DataClassObjString, object : TypeToken<OptionId1DataClass>() {}.type)
        val optionId1OptionObjHashSet = optionId1DataClassObj.hashSetOfOption
        val optionId1MeterObjHashSet = optionId1DataClassObj.hashSetOfMeter
        val optionId1YardObjHashSet = optionId1DataClassObj.hashSetOfYard
        for (obj in optionId1OptionObjHashSet.iterator()){
            if (obj.title == requireArguments().getString("OptionId1SelectedTitle")) {
                option1 = obj.value.toInt()
                break
            }
        }
        for (obj in optionId1MeterObjHashSet.iterator()){
            if (obj.title == requireArguments().getString("OptionId1SelectedTitle")) {
                option1 = obj.value.toInt()
                break
            }
        }
        for (obj in optionId1YardObjHashSet.iterator()){
            if (obj.title == requireArguments().getString("OptionId1SelectedTitle")) {
                option1 = obj.value.toInt()
                break
            }
        }


        val optionId2DataClassObjString = pSharedPref?.getString("optionId2DataClassObjString", "optionId2DataClassObjStringNotExist")
        val optionId2DataClassObj: OptionId2DataClass = Gson().fromJson(optionId2DataClassObjString, object : TypeToken<OptionId2DataClass>() {}.type)
        val optionId2OptionObjHashSet = optionId2DataClassObj.hashSetOfOption
        for (obj in optionId2OptionObjHashSet.iterator()) {
            if (obj.title == requireArguments().getString("OptionId2SelectedTitle")) {
                option2 = obj.value.toDouble()
                appPreferences.isImperial = option2.toInt() != 1
                break
            }
        }

        val optionId3DataClassObjString = pSharedPref?.getString("OptionId3DataClassObjString", "OptionId3DataClassObjStringNotExist")
        val optionId3DataClassObj: OptionId3DataClass = Gson().fromJson(optionId3DataClassObjString, object : TypeToken<OptionId3DataClass>() {}.type)
        val optionId3OptionObjHashSet = optionId3DataClassObj.hashSetOfOption
        for (obj in optionId3OptionObjHashSet.iterator()) {
            if (obj.title == requireArguments().getString("OptionId3SelectedTitle")) {
                option3 = obj.value.toDouble()
                break
            }
        }


        millisInFuture = (pSharedPref!!.getString("totalTimeDurToRecSoundString","5000000")?.toDouble()!! * 1000).toLong()




        val optionId5DataClassObjString = pSharedPref?.getString("OptionId5DataClassObjString", "OptionId5DataClassObjStringNotExist")
        val optionId5DataClassObj: OptionId5DataClass = Gson().fromJson(optionId5DataClassObjString, object : TypeToken<OptionId5DataClass>() {}.type)
        val optionId5OptionObjHashSet = optionId5DataClassObj.hashSetOfOption
        for (obj in optionId5OptionObjHashSet.iterator()) {
            if (obj.title == requireArguments().getString("OptionId5SelectedTitle")) {
                option5 = obj.value.toDouble()
                break
            }
        }
    }






    private fun getAllOptionForOptionBox6() {
        optionBox6 = ArrayList()
        val optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj:OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption

        for (obj in optionId6OptionHashSet.iterator())
        {
            optionBox6.add(obj.title)
        }
    }

    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.bowlingSpeedTitleTv.text = getString(R.string.bowling_speed_km_hr)
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_km_hr)
            binding.aerialTravelDistanceTitleTv.text = getString(R.string.aerial_travel_distnace_meters)
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_km_hr)
        }else{
            binding.bowlingSpeedTitleTv.text = getString(R.string.bowling_speed_mile_hr)
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_mile_hr)
            binding.aerialTravelDistanceTitleTv.text = getString(R.string.aerial_travel_distance_yard)
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_mile_hr)
        }
    }

    private fun getHasSetToCheckCondtionOfAudio() {
        val objectOfInputValuesDataClassString = pSharedPref?.getString("objectOfInputValuesDataClassString", "objectOfInputValuesDataClassStringNotExist")
        val type: Type? = object : TypeToken<InputValuesDataClass>() {}.type
        val objectOfInputValuesDataClass: InputValuesDataClass = Gson().fromJson(objectOfInputValuesDataClassString, type)
        minDB1 = objectOfInputValuesDataClass.minDB1.toDouble()
        maxDB1  = objectOfInputValuesDataClass.maxDB1.toDouble()
        Log.i(TAG, "getHasSetToCheckCondtionOfAudio: fdsa $minDB1, fddfs $maxDB1")
        minFrequency1 = objectOfInputValuesDataClass.minFrequency1.toDouble()
        maxFrequency1 = objectOfInputValuesDataClass.maxFrequency1.toDouble()
        soundEndDuration = (objectOfInputValuesDataClass.soundEndDuration.toDouble() * 1000)
       /* minDB2 = objectOfInputValuesDataClass.minDB2.toDouble()
        maxDB2  = objectOfInputValuesDataClass.maxDB2.toDouble()*/
        Log.i(TAG, "getHasSetToCheckCondtionOfAudio: fdsa $minDB1, fddfs $maxDB1")
       /* minFrequency2 = objectOfInputValuesDataClass.minFrequency2.toDouble()
        maxFrequency2 = objectOfInputValuesDataClass.maxFrequency2.toDouble()*/
        soundDurationFromStartButton = (objectOfInputValuesDataClass.soundDurationFromStartButton * 1000)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun startRecording() {
        (activity as MainActivity).isOutput3Visible = false
        resetData()
        viewModel.heighest.value = 0.0
         binding.allSummaryScrollview.visibility = View.GONE
        val minBufferSize = AudioRecord.getMinBufferSize(RECORDER_SAMPLERATE, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING)
        recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                RECORDER_SAMPLERATE,
                RECORDER_CHANNELS,
                RECORDER_AUDIO_ENCODING,
                (minBufferSize )
        )
        Log.i(TAG, "writeAudioDataToFile: cdount")
        startTimeMillis = System.currentTimeMillis()
        val milliseconds: Double = System.currentTimeMillis().toDouble()
        val seconds = (milliseconds / 1000)
        startTimeStamp = String.format("%3f", seconds)
        recorder!!.startRecording()
        Log.i(TAG, "onCreate: seconssss $startTimeStamp")
        isRecording = true
        recordingThread = Thread({ writeAudioDataToFile(minBufferSize ) }, "AudioRecorder Thread")
        recordingThread!!.start()
        isRecordingStart = true
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun writeAudioDataToFile(minBufferSize: Int) {
        val audioCalculator = AudioCalculator()
        filePath = mContext!!.externalCacheDir!!.absolutePath
        filePath += "/audiorecordtest.3gp"
        val sData = ByteArray(minBufferSize)
        var os: FileOutputStream? = null
        try {
            os = FileOutputStream(filePath)
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        }

        while (isRecording) {

            recorder!!.read(sData, 0, minBufferSize)
            try {
                audioCalculator.setBytes(sData)
                val amplitude = audioCalculator.amplitude
                val decibel = audioCalculator.decibel
                val frequency = audioCalculator.frequency
                Log.i(TAG, "writeAudioDataToFileee: "+System.currentTimeMillis())
                Log.i(TAG, "writeAudioDataToFile: ${sData.size} amp "+amplitude+" , decibel "+decibel+" , frequency "+frequency)
                calculate((getDBA(decibel, frequency) + 10), frequency)
             } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        try {
            os!!.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun calculate(db: Double, frequency: Double) {
        Log.i(TAG, "calculate: donotgoinFirt $doNotGoInFirst coming db $db maxDB1 $maxDB1 minDB1 $minDB1  minFrequency1 $minFrequency1 maxFrequency1 $maxFrequency1 frequency $frequency" )
        Log.i(TAG, "calculate: timeAfterSound1Recorded $timeAfterSound1Recorded soundEndDuration $soundEndDuration soundDurationFromStartButton $soundDurationFromStartButton startTimeMillis $startTimeMillis dontoinSecond $doNotGoInSecond maxdb2 $maxDB2 mindb2 $minDB2 minfr2 $minFrequency2 maxfr2 $maxFrequency2")
        if(System.currentTimeMillis() > (startTimeMillis + soundDurationFromStartButton!!)){
            Log.i(TAG, "calculate: it commding")
            if(!doNotGoInFirst){
                if (System.currentTimeMillis() < (startTimeMillis + soundEndDuration!!)){
                    if (db < maxDB1!! && db > minDB1!! && frequency > minFrequency1!! && frequency < maxFrequency1!!){
                        arrayListOfSounds[0].add(db)
                        val milliseconds: Double = System.currentTimeMillis().toDouble() 
                        val seconds = (milliseconds / 1000)
                        firstPeakTimeStamp = String.format("%3f", seconds)
                        Log.i(TAG, "calculate: cam11")
                    }else{
                        if (arrayListOfSounds[0].isNotEmpty()){
                            doNotGoInFirst = true
                            Log.i(TAG, "calculate: gggg $firstPeakTimeStamp")
                        }
                    }
                }else{
                    doNotGoInFirst = true

                    Log.i(TAG, "calculate: wwwww $firstPeakTimeStamp")
                }
            }
        }/*else{
            if(!doNotGoInFirst){
                if (System.currentTimeMillis() < (startTimeMillis + soundEndDuration!!)){
                    if (db < maxDB1!! && db > minDB1!! && frequency > minFrequency1!! && frequency < maxFrequency1!!){
                        arrayListOfSounds[0].add(db)
                        val milliseconds: Double = System.currentTimeMillis().toDouble()
                        val seconds = (milliseconds / 1000)
                            firstPeakTimeStamp = String.format("%3f", seconds)
                        Log.i(TAG, "calculate: cam11")
                    }else{
                        if (arrayListOfSounds[0].isNotEmpty()){
                            doNotGoInFirst = true
                            timeAfterSound1Recorded = System.currentTimeMillis()
                            Log.i(TAG, "calculate: gggg $firstPeakTimeStamp")
                        }
                    }
                }else{
                    doNotGoInFirst = true
                    if (timeAfterSound1Recorded == 0.toLong()){
                        timeAfterSound1Recorded = System.currentTimeMillis()
                        Log.i(TAG, "calculate: qqqqqq $firstPeakTimeStamp")

                    }
                    Log.i(TAG, "calculate: wwwww $firstPeakTimeStamp")
                }
            }else{
                *//*if (!doNotGoInSecond){
                    if (arrayListOfSounds[0].isNotEmpty()){
                        if (System.currentTimeMillis() < (timeAfterSound1Recorded + durationBetweenTwoSound!!)){
                            if (db < maxDB2!! && db > minDB2!! && frequency > minFrequency2!! && frequency < maxFrequency2!!){
                                arrayListOfSounds[1].add(db)
                                val milliseconds: Double = System.currentTimeMillis().toDouble()
                                val seconds = (milliseconds / 1000)
                                secondPeakTimeStamp = String.format("%3f", seconds)
                                Log.i(TAG, "calculate: cam22")
                            }else{
                                if (arrayListOfSounds[1].isNotEmpty()){
                                    doNotGoInSecond = true
                                    Log.i(TAG, "calculate: eeee $secondPeakTimeStamp")
                                 }
                            }
                        }
                    }else{
                        if (db < maxDB2!! && db > minDB2!! && frequency > minFrequency2!! && frequency < maxFrequency2!!){
                            arrayListOfSounds[1].add(db)
                            val milliseconds: Double = System.currentTimeMillis().toDouble()
                            val seconds = (milliseconds / 1000)
                            secondPeakTimeStamp = String.format("%3f", seconds)
                            Log.i(TAG, "calculate: cam33")
                        }else{
                            if (arrayListOfSounds[1].isNotEmpty()){
                                doNotGoInSecond = true
                                Log.i(TAG, "calculate: nnnnn $secondPeakTimeStamp")
                            }
                        }
                    }
                }*//*
            }
        }*/
    }


    private fun getDBA(decibel: Double, frequency: Double): Double {
        if (frequency > 44) {
            if (frequency >= 44 && frequency < 88) {
                return (decibel + (-26.2))
            } else if (frequency >= 88 && frequency < 177) {
                return (decibel + (-16.1))
            } else if (frequency >= 177 && frequency < 355) {
                return (decibel + (-8.6))
            } else if (frequency >= 355 && frequency < 710) {
                return (decibel + (-3.2))
            } else if (frequency >= 710 && frequency < 1420) {
                return (decibel + 0)
            } else if (frequency >= 1420 && frequency < 2840) {
                return (decibel + 1.2)
            } else if (frequency >= 2840 && frequency < 5680) {
                return (decibel + 1)
            } else if (frequency >= 5680 && frequency < 11360) {
                return (decibel + (-1.1))
            } else if (frequency >= 11360 && frequency < 22720) {
                return (decibel + (-6.6))
            }
        } else {
            return decibel
        }
        return decibel
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun stopRecording() {
        isRecording = false
        recorder!!.stop()
        recorder!!.release()
        recorder = null
        recordingThread = null
        val intent = Intent(requireContext(), PickerViewActivity()::class.java)
        startActivity(intent)
        /*ShotTypeDialogFragment(this).show(childFragmentManager, TAG)*/
    }



    @RequiresApi(Build.VERSION_CODES.M)
    private fun callApiForCalculation(
        pickDecibelForsound1: Double,
        pickDecibelForSound2: Double
    ) {
        binding.cpCardview.visibility = View.VISIBLE

        val map = HashMap<String, Any>()

        map["option1"] = option1
        map["option2"] = option2
        map["option3"] = option3
        map["option5"] = option5
        map["avgDB1"] = pickDecibelForsound1
       /* map["avgDB2"] = pickDecibelForSound2*/
        map["startTimeStamp"] = startTimeStamp
        map["deviceType"] = "A"
        if (firstPeakTimeStamp != ""){
            map["firstPeakTimeStamp"] = firstPeakTimeStamp
        }else{
            map["firstPeakTimeStamp"] = 0.00
        }
       /* if (secondPeakTimeStamp != ""){
            map["secondPeakTimeStamp"] = secondPeakTimeStamp
        }else{
            map["secondPeakTimeStamp"] = 0.00
        }*/
        map["selectedShortValue"] = selectedShotType
        map["sessionAverageOutput1"] = getAverageOfOutput1FromSession()
        Log.i(TAG, "callApiForCalculation: prindf "+getAverageOfOutput1FromSession())
        Log.i(TAG, "callApiForCalculation: dkkkkkkjhjdddd $map   " )
        binding.sentDb.text = "max db "+map["avgDB1"].toString()
        binding.sentStartTime.text = "recording start timestamp "+map["startTimeStamp"].toString()
        binding.sentSoundCapturedTime.text = "sound picked timestamp "+map["firstPeakTimeStamp"].toString()


        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        binding.recoderStartAndStop.isClickable = false
        call.getCalculation(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                resetData()
                  try {
                    val errorBody = response.errorBody()
                    if (response.body() == null) {
                        val errorText = errorBody?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(mContext,
                                errorJsonObj.getString("message"),
                                Toast.LENGTH_LONG
                        ).show()
                    } else {
                        val res = Gson().toJson(response.body())
                         val mainObject = JSONObject(res)
                         if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            val arrayOfOutputs = mainObject.getJSONArray("data")
                             Log.i(TAG, "onResponse: arrree "+arrayOfOutputs)
                            setAllOutputs(arrayOfOutputs.get(0).toString().toDouble(), arrayOfOutputs.get(1).toString().toDouble(), arrayOfOutputs.get(2).toString().toDouble(), arrayOfOutputs.get(3).toString().toDouble())
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(mContext,
                                    mainObject.getString("message"),
                                    Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                resetData()
                 binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun getAverageOfOutput1FromSession(): Double {
        val jsHashSetOutput1String = pSharedPref!!.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
        val gson = Gson()
        val type: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.type
        val SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = gson.fromJson(jsHashSetOutput1String, type)
        val list: ArrayList<SumarryOutput1DataClass> = ArrayList<SumarryOutput1DataClass>(SumarryOutput1DataClassHashSet)
        var total = 0.0
        for (obj in list.iterator()){
            total += obj.output.toDouble()
            Log.i(TAG, "getAverageOfOutput1FromSession: peiidn $obj")
        }
        if (list.size == 0){
            return  0.0
        }else{
            return total / list.size
        }
    }

    private fun  setAllOutputs( output1: Double, output2: Double, output3: Double, output4: Double) {
        var _output1 = output1
        var _output2 = output2
        var _output3 = output3
        var _output4 = output4


        if ( selectedShotType.contains("Throw") || selectedShotType.contains("Bouncer")){
            _output2 = 0.0
            _output3 = 0.0
            _output4 = 0.0
        }
         setOutput(dec.format(_output1), dec.format(_output2), dec.format(_output3), dec.format(_output4))
        if ((_output1 == 0.0) && (_output2 == 0.0)){

        }else{
            for (option in optionId6OptionHashSet.iterator()) {
                if (selectedShotType.contains(option.title)) {
                    if (appPreferences.isImperial){
                        val summaryOutput1DataClassObj = SumarryOutput1DataClass((outputs1.size + 1) , dec.format((_output1 * 0.621)).toString(), option.factor1 , option.factor2 )
                        outputs1.add(summaryOutput1DataClassObj)
                    }else{
                        val summaryOutput1DataClassObj = SumarryOutput1DataClass((outputs1.size + 1) , dec.format(_output1).toString(), option.factor1 , option.factor2 )
                        outputs1.add(summaryOutput1DataClassObj)
                    }
                }
            }
            for (option in optionId6OptionHashSet.iterator()) {
                if (selectedShotType.contains(option.title)) {
                    if (appPreferences.isImperial){
                        val summaryOutput2DataClassObj = SumarryOutput2DataClass((outputs2.size + 1) ,dec.format((_output2 * 0.621)).toString(), option.title, dec.format((_output4 * 0.621)).toString())
                        outputs2.add(summaryOutput2DataClassObj)
                    }else{
                        val sumaryOutput2DataClassObj = SumarryOutput2DataClass((outputs2.size + 1) ,dec.format(_output2 ).toString(), option.title, dec.format(_output4).toString())
                        outputs2.add(sumaryOutput2DataClassObj)
                    }
                }
            }

            for (option in optionId6OptionHashSet.iterator()) {
                if (selectedShotType.contains("Lofted")){
                    if (selectedShotType.contains(option.title)) {
                        if (appPreferences.isImperial){
                            val summaryOutput3DataClassObj = SumarryOutput3DataClass((outputs3.size + 1) , dec.format((_output3 * 1.094)).toString(), option.title)
                            outputs3.add(summaryOutput3DataClassObj)
                        }else{
                            val summaryOutput3DataClassObj = SumarryOutput3DataClass((outputs3.size + 1) , dec.format(_output3 ).toString(), option.title)
                            outputs3.add(summaryOutput3DataClassObj)
                        }
                    }
                }
            }
            setOutputsResultToSharedPref()
        }

    }

    private fun setOutput(
            output1_db: String,
            output2_db: String,
            output3_db: String,
            output4_db: String
    ) {
        if (appPreferences.isImperial){
            binding.output1DbTextview.text = (dec.format(output1_db.toDouble() * 0.621)).toString()
            binding.output3DbTextview.text = (dec.format(output3_db.toDouble() * 1.094) ).toString()
            if (selectedShotType.contains("Leave") || selectedShotType.contains("Bouncer")){
                binding.output2DbTextview.text = "0.00"
                binding.output4DbTextview.text = "0.00"
            }else{
                binding.output4DbTextview.text = (dec.format(output4_db.toDouble() * 0.621) ).toString()
            }
            binding.output2DbTextview.text = (dec.format(output2_db.toDouble() * 0.621) ).toString()
            if (output2_db.toDouble() == 0.0){
                binding.output2DbTextview.text = "0.00"
                binding.output4DbTextview.text = "0.00"
            }
        }else{
            binding.output1DbTextview.text = (dec.format(output1_db.toDouble() )).toString()
            binding.output3DbTextview.text = (dec.format(output3_db.toDouble() ) ).toString()
            if (selectedShotType.contains("Leave") || selectedShotType.contains("Bouncer")){
                binding.output2DbTextview.text = "0.00"
                binding.output4DbTextview.text = "0.00"
            }else{
                binding.output4DbTextview.text = (dec.format(output4_db.toDouble() ) ).toString()
            }
            binding.output2DbTextview.text = (dec.format(output2_db.toDouble() ) ).toString()
            if (output2_db.toDouble() == 0.0){
                binding.output2DbTextview.text = "0.00"
                binding.output4DbTextview.text = "0.00"
            }
        }

        binding.allSummaryScrollview.visibility = View.VISIBLE
        if ((activity as MainActivity).isOutput3Visible) {
            binding.summary3View.visibility = View.VISIBLE
        } else {
            binding.summary3View.visibility = View.GONE
        }
    }

    private fun setOutputsResultToSharedPref() {
        Log.i(TAG, "setOutputsResultToSharedPref: outpu1 $outputs1")
        val jsHashSetOutput1String = Gson().toJson(outputs1)
        val jsHashSetOutput2String = Gson().toJson(outputs2)
        val jsHashSetOutput3String = Gson().toJson(outputs3)
        pSharedPref!!.edit().putString("jsHashSetOutput1String", jsHashSetOutput1String).apply()
        pSharedPref!!.edit().putString("jsHashSetOutput2String", jsHashSetOutput2String).apply()
        pSharedPref!!.edit().putString("jsHashSetOutput3String", jsHashSetOutput3String).apply()
    }


    private val mMessageReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        @RequiresApi(Build.VERSION_CODES.M)
        override fun onReceive(context: Context?, intent: Intent) {
            // Get extra data included in the Intent
              selectedShotType = intent.getStringExtra("selectedItem").toString()
            if (selectedShotType.contains("Lofted")  ){
                (activity as MainActivity).isOutput3Visible = true
            }
            var pickDecibelForSound1 = 0.0
            var pickDecibelForSound2 = 0.0
            var sound1 = arrayListOfSounds[0]
            val sound2 = arrayListOfSounds[1]

            Log.i(TAG, "onReceive: sou1 $sound1  sou2 $sound2")
             if (sound1.size == 0){
                if (sound2.size == 0){
                     callApiForCalculation(pickDecibelForSound1, pickDecibelForSound2  )
                }else{
                    sound1 = sound2
                    firstPeakTimeStamp = secondPeakTimeStamp
                    secondPeakTimeStamp = ""
                    for (db in sound1.iterator())
                    {
                        if (db > pickDecibelForSound1){
                            pickDecibelForSound1 = db
                        }
                    }
                    pickDecibelForSound2 = 0.0
                    callApiForCalculation(pickDecibelForSound1, pickDecibelForSound2  )
                }
            }else{
                for (db in sound1.iterator())
                {
                    if (db > pickDecibelForSound1){
                        pickDecibelForSound1 = db
                    }
                }

                if (sound2.size != 0){
                    for (db in sound2.iterator())
                    {
                        if (pickDecibelForSound2 < db){
                            pickDecibelForSound2 = db
                        }
                    }
                }else{
                    pickDecibelForSound2 = 0.0
                }

                (activity as MainActivity).dataRecorded = true
                val arrayOfShotType = arrayListOf("Snick Leg Back Foot", "Snick Leg Front Foot", "Outside Edge Back Foot", "Outside Edge Front Foot", "Leave Leg", "Leave Off", "Bouncer", "Throw Down 3 m ", "Throw Down 4 m", "Throw Down 5 m", "Throw Down 6 m")
                if (selectedShotType != ""){
                    if (arrayOfShotType.contains(selectedShotType)  ){
                        pickDecibelForSound2 = 0.0
                        secondPeakTimeStamp = ""
                    }
                    if (selectedShotType.contains("Leave") || selectedShotType.contains("Throw")){
                        pickDecibelForSound2 = 0.0
                        secondPeakTimeStamp = ""
                    }

                }
                callApiForCalculation(pickDecibelForSound1, pickDecibelForSound2  )
            }

        }
    }


    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(requireContext()).unregisterReceiver(mMessageReceiver)
    }



    @RequiresApi(Build.VERSION_CODES.M)
    override fun onClick(v: View?) {
        when (v){
            binding.recoderStartAndStop -> {
                Log.i(TAG, "onClick: aaaaaa "+soundDurationFromStartButton)
                Log.i(TAG, "onClick: bbbbbb "+soundEndDuration)
                Log.i(TAG, "onClick: cccccc "+millisInFuture)
                if (!isRecordingStart) {
                    binding.recoderStartAndStop.setImageResource(R.drawable.stop)
                    startRecording()
                    object : CountDownTimer(millisInFuture, 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                            if (!isRecordingStart) {
                                cancel()
                                binding.textviewStartAndTimer.text = getString(R.string.start)
                            }
                        }

                        override fun onFinish() {
                            if (recorder != null){
                                stopRecording()
                                binding.textviewStartAndTimer.text = getString(R.string.start)
                                binding.recoderStartAndStop.setImageResource(R.drawable.start)
                                isRecordingStart = false
                            }
                        }
                    }.start()
                } else {
                    binding.textviewStartAndTimer.text = getString(R.string.start)
                    binding.recoderStartAndStop.setImageResource(R.drawable.start)
                    isRecordingStart = false
                    stopRecording()
                }
            }

            binding.backBtn -> {
                (activity as MainActivity).popFragments()
            }

            binding.summary1 -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, BowlingSessionSummaryFragment(), true)
            }

            binding.summary2 -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, BatSwingSessionSummaryFragment(), true)
            }

            binding.summary3 -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, AerialTravelSessionSummaryFragment(), true)
            }

            binding.summary4 -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, BallExistSessionSummaryFragment(), true)
            }


            binding.btnUploadData -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, UploadDataFragment(), true)
            }
        }
    }

    companion object {
        const val TAG = "StartFragment"
    }



    private fun resetData() {
        binding.recoderStartAndStop.isClickable = true
        startTimeStamp = ""
        firstPeakTimeStamp = ""
        secondPeakTimeStamp = ""
        isRecordingStart = false
        doNotGoInFirst = false
        doNotGoInSecond = false
        arrayListOfSounds[0] = ArrayList()
        arrayListOfSounds[1] = ArrayList()
        timeAfterSound1Recorded = 0
    }


}