package com.app.cricketstats.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.provider.MediaStore
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.app.cricketstats.R
import com.app.cricketstats.models.SumarryOutput1DataClass


class GlobalOperation {
    var isLogout = false



    companion object {
        fun showDialog(context: Context?, msg: String?) {
            val dialog = Dialog(context!!)
            dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.alert_dialog)
            val text = dialog.findViewById<TextView>(R.id.cp_title) as TextView
            text.text = msg
            val dialogButton: Button = dialog.findViewById<Button>(R.id.alert_ok_btn) as Button
            dialogButton.setOnClickListener {
                dialog.dismiss()
            }
            dialog.show()
        }

        fun dialogToTakeImage(activity: Activity?) {
            val dialog = Dialog(activity!!)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_layout_to_take_picture)
            val camera = dialog.findViewById<TextView>(R.id.camera) as TextView
            camera.setOnClickListener {
                val takePicture = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                activity.startActivityForResult(takePicture, 0)
                dialog.dismiss()
            }
            val gallary = dialog.findViewById<TextView>(R.id.gallary) as TextView
            gallary.setOnClickListener {
                val pickPhoto = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                activity.startActivityForResult(pickPhoto, 1)
                dialog.dismiss()
            }
            val cancel = dialog.findViewById<TextView>(R.id.cancel) as TextView
            cancel.setOnClickListener {
                dialog.dismiss()
            }
            dialog.show()
        }

        fun showDataUploadedDialog(context: Context?) {
            val dialog = Dialog(context!!)
            dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.uploaded_data_dialog_box)
            val dialogButton: Button = dialog.findViewById<Button>(R.id.data_uploaded_dialog_ok_btn) as Button
            dialogButton.setOnClickListener {
                dialog.dismiss()
            }
            dialog.show()
        }


        fun getFactor2ArrayList(list: ArrayList<SumarryOutput1DataClass>): Any {
            var straight = 0
            var off = 0
            var wideOfOff = 0
            var wideOfLeg = 0
            var leg = 0
            for (obj in list.iterator()) {
                if (obj.orientation.toString().equals("Straight")) {
                    straight++
                }
                if (obj.orientation.toString().equals("Off")) {
                    off++
                }
                if (obj.orientation.toString().equals("Wide of off")) {
                    wideOfOff++
                }
                if (obj.orientation.toString().equals("Wide of leg")) {
                    wideOfLeg++
                }
                if (obj.orientation.toString().equals("Leg")) {
                    leg++
                }
            }

            if ((straight + off + wideOfOff + wideOfLeg + leg) != 0) {
                var aPercent = ((straight * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
                var bPercent = ((off * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
                var cPercent = ((wideOfOff * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
                var dPercent = ((wideOfLeg * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
                var ePercent = ((leg * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
                return arrayListOf(aPercent, bPercent, cPercent, dPercent, ePercent)
            } else {
                return arrayListOf(0.0, 0.0, 0.0, 0.0, 0.0)
            }
        }

        fun getFactor1ArrayList(list: ArrayList<SumarryOutput1DataClass>): Any {
            var full = 0
            var good = 0
            var short = 0
            for (obj in list.iterator()) {
                if (obj.frequency.toString().equals("Full")) {
                    full++
                }
                if (obj.frequency.toString().equals("Good")) {
                    good++
                }
                if (obj.frequency.toString().equals("Short")) {
                    short++
                }
            }

            if ((full + good + short) != 0) {
                var fPercent = ((full * 100) / (full + good + short))
                var gPercent = ((good * 100) / (full + good + short))
                var sPercent = ((short * 100) / (full + good + short))
                return arrayListOf(sPercent, gPercent, fPercent)

            } else {
                return arrayListOf(0.0, 0.0, 0.0)
            }
        }

        //@RequiresApi(Build.VERSION_CODES.M)
        fun isNetworkConnected(context: Context?): Boolean {
            val cm = context?.getSystemService(AppCompatActivity.CONNECTIVITY_SERVICE) as ConnectivityManager
            return cm.activeNetwork != null
        }


        private const val TAG = "GlobalOperation"
    }
}