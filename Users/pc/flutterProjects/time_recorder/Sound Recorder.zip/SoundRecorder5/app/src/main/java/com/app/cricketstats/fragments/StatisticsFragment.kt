package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.databinding.FragmentStatisticsBinding


class StatisticsFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentStatisticsBinding
    var pSharedPref: SharedPreferences? = null
    var mContext: Context? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentStatisticsBinding.inflate(inflater, container, false)
        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
        setUiAction()
        return binding.getRoot()
    }

    private fun setUiAction() {
        setOnClickListener()

    }



    private fun setOnClickListener() {
         binding.bowlingDataAnalysis.setOnClickListener(this)
        binding.battingDataAnalysis.setOnClickListener(this)
        binding.aerialTravelDistanceDataAnalysis.setOnClickListener(this)
        binding.ballExitDataAnalysis.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)

    }


    override fun onClick(v: View?) {
         when(v) {
             binding.backBtn -> {
                 (activity as MainActivity).popFragments()
             }
             binding.bowlingDataAnalysis -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, StastisticBowlingDataAnalysisFragment(),true)
             }
             binding.battingDataAnalysis -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, StatisticsBattingDataAnalysisFragment(),true)
             }
             binding.aerialTravelDistanceDataAnalysis -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, StatisticsAerialTravelDistanceDataAnalysisFragment(),true)
             }
             binding.ballExitDataAnalysis -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, StatisticsBallExitDataAnalysisFragment(),true)
             }
         }
    }

}