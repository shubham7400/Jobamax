package com.app.cricketstats.models

data class SumarryOutput1DataClass(val sequenceNum: Int, val output: String,val orientation: String, val frequency: String)