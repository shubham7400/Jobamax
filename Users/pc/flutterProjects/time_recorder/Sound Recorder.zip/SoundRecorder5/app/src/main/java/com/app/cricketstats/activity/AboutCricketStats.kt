package com.app.cricketstats.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.view.View
import com.app.cricketstats.R
import com.app.cricketstats.databinding.ActivityAboutCricketStatsBinding

class AboutCricketStats : AppCompatActivity(), View.OnClickListener {
    lateinit var binding: ActivityAboutCricketStatsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutCricketStatsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        setUiAction()

    }

    private fun setUiAction() {
         binding.signupToBuyAndUseNowBtn.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)
        binding.aboutCricketStatsAppTv.setText(Html.fromHtml(getString(R.string.about_cricket_stats_app)))
    }

    override fun onBackPressed() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    override fun onClick(v: View?) {
         when(v){
             binding.signupToBuyAndUseNowBtn -> {
                 startActivity(Intent(this, PaymentActivity::class.java))
             }
             binding.backBtn -> {
                 startActivity(Intent(this, LoginActivity::class.java))
                 finish()
             }
         }
    }
}