package com.app.cricketstats.activity

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.app.cricketstats.R
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.ActivityLoginBinding
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.google.gson.Gson
import org.checkerframework.checker.units.qual.A
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response


class LoginActivity : AppCompatActivity(), View.OnClickListener{
    lateinit var binding: ActivityLoginBinding
    var pSharedPref: SharedPreferences? = null

   /* private val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"*/
    lateinit var appPreferences: AppPreferences
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(view)

        pSharedPref = getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(this)
        binding.textviewToGoSignupForm.setOnClickListener(this)
        binding.btnLogin.setOnClickListener(this)
        binding.forgotPasswordTv.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)

        var companyName = pSharedPref?.getString("companyNameString", "companyNameStringNotExist").toString().replace(
            "\"",
            ""
        );
        binding.companyNameText.text = companyName
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun login() {
        if (binding.emailUser.text.isBlank() /*|| (!binding.emailUser.text.matches(emailPattern.toRegex()))*/) {
            GlobalOperation.showDialog(this, "Email can not be empty")
            binding.emailUser.requestFocus()
            /*if ((!binding.emailUser.text.matches(emailPattern.toRegex())) && (!binding.emailUser.text.isBlank())){
                GlobalOperation.showDialog(this, "Invalid email pattern ")
                binding.emailUser.requestFocus()
            }else{
                GlobalOperation.showDialog(this, "Email can not be empty")
                binding.emailUser.requestFocus()
            }*/
        }else if ( binding.passwordUser.text.isBlank()/* || binding.passwordUser.text.length < 8*/){
            if (binding.passwordUser.text.isBlank()){
                GlobalOperation.showDialog(this, "Please enter password")
                binding.passwordUser.requestFocus()
            }/*else{
                GlobalOperation.showDialog(this,"Passsword should be atleast 8 digit")
                binding.passwordUser.requestFocus()
            }*/
        }else{
            getLogin(binding.emailUser.text.toString(), binding.passwordUser.text.toString())
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun getLogin(email: String, password: String) {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, String>()
        map["email"] = email
        map["password"] = password
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.userLogin(map).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    var errorBody = response.errorBody()
                    if (response.body() == null) {
                        val errorText = errorBody?.string()!!
                        Log.i(TAG, "onResponse: ksdafsd " + errorText)
                        val errorJsonObj = JSONObject(errorText)
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(
                            this@LoginActivity,
                            errorJsonObj.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        val res = Gson().toJson(response.body())
                        Log.i(TAG, "onResponse: res is " + res)
                        val mainObject = JSONObject(res)
                        Log.d("CREATE_FEED_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            Toast.makeText(
                                this@LoginActivity,
                                "user successfully has been logedIn.",
                                Toast.LENGTH_LONG
                            ).show()
                            appPreferences.email =
                                mainObject.getJSONObject("data").optString("email")
                            appPreferences.uuid = mainObject.getJSONObject("data").optString("uuid")
                            appPreferences.token =
                                mainObject.getJSONObject("data").optString("token")
                            appPreferences.ageGroup =
                                mainObject.getJSONObject("data").optString("ageGroup")
                            appPreferences.profileUrl =
                                mainObject.getJSONObject("data").optString("profileUrl")
                            appPreferences.name = mainObject.getJSONObject("data").optString("name")
                            appPreferences.isImperial = false
                            binding.cpCardview.visibility = View.GONE
                            if (mainObject.getJSONObject("data").opt("isPaymentDone") == false) {
                                val intent = Intent(
                                    this@LoginActivity,
                                    AboutCricketStats::class.java
                                )
                                startActivity(intent)
                                finish()
                            } else if (mainObject.getJSONObject("data")
                                    .opt("isProfileSetup") == false
                            ) {
                                val intent = Intent(
                                    this@LoginActivity,
                                    PersonalDetailsActivity::class.java
                                )
                                startActivity(intent)
                                finish()
                            } else {
                                appPreferences.isLogin = true
                                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                startActivity(intent)
                             }
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            GlobalOperation.showDialog(
                                this@LoginActivity, "" + mainObject.getString(
                                    "message"
                                )
                            )
                            Toast.makeText(
                                this@LoginActivity,
                                mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    /*Toast.makeText(this@LoginActivity,e.message.toString(),Toast.LENGTH_LONG).show()*/
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    fun forgotPasswordDialog() {
        val dialog = Dialog(this!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.forgot_password_dialog)
        val forgotPasswordBtn = dialog.findViewById<TextView>(R.id.forgot_password_tv_btn) as TextView
        var emailAddressEdt = dialog.findViewById<EditText>(R.id.email_address_edt)
        forgotPasswordBtn.setOnClickListener {
            if (emailAddressEdt.text != null){
                resetPassword(emailAddressEdt.text.toString())
            }else{
                GlobalOperation.showDialog(this, "Please Enter email address.")
            }
            dialog.dismiss()
        }
        val cancel = dialog.findViewById<TextView>(R.id.cancel_tv_btn) as TextView
        cancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun resetPassword(emailAddress: String) {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, String>()
        map.put("email", emailAddress)
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.forgotPassword(map).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    var errorBody = response.errorBody()
                    if (response.body() == null) {
                        val errorText = errorBody?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(
                            this@LoginActivity,
                            errorJsonObj.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        binding.cpCardview.visibility = View.GONE
                        val res = Gson().toJson(response.body())
                        Log.i(TAG, "onResponse: resSS is " + res)
                        val mainObject = JSONObject(res)
                        Log.d("RESET_PASS_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            Toast.makeText(
                                this@LoginActivity,
                                "" + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()

                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                this@LoginActivity,
                                mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Toast.makeText(this@LoginActivity, e.message.toString(), Toast.LENGTH_LONG)
                        .show()
                    Log.i(TAG, "onResponse: exception is hDDer " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }


    @RequiresApi(Build.VERSION_CODES.M)
    override fun onClick(v: View?) {
         when(v){
             binding.textviewToGoSignupForm -> {
                 startActivity(Intent(this, SignupActivity::class.java))
                 finish()
             }
             binding.btnLogin -> {
                 if (GlobalOperation.isNetworkConnected(this)) {
                     login()
                 } else {
                     GlobalOperation.showDialog(
                         this,
                         "Please make sure that you are connected with network."
                     )
                 }
             }
             binding.forgotPasswordTv -> {
                 forgotPasswordDialog()
             }
             binding.backBtn -> {
                 finish()
                 onBackPressed()
             }
         }
    }

    companion object {
        private const val TAG = "LoginActivity"
    }
}