package com.app.cricketstats.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.cricketstats.R
import com.app.cricketstats.models.SumarryOutput1DataClass

class SummaryOutput1Adapter(context: Context, var list: List<SumarryOutput1DataClass>) : RecyclerView.Adapter<SummaryOutput1Adapter.ViewHolder>() {
    /*var myPref: SharedPreferences = context.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
    var jsHashSetOutput1String = myPref.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
    var gson = Gson()
    var type: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.type
    var SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = gson.fromJson(jsHashSetOutput1String, type)
    var list: List<SumarryOutput1DataClass> = ArrayList(SumarryOutput1DataClassHashSet).reversed()*/

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        return  ViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.summary_output1_recyclerview_layout,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var sumarryOutput1DataClassObj = list[position]
        holder.ballNumber.text = (position + 1).toString()
        holder.bind(sumarryOutput1DataClassObj)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    class ViewHolder(view: View) :RecyclerView.ViewHolder(view)
    {
        var ballNumber: TextView = view.findViewById(R.id.ball_number)
        var bowlingSpeed: TextView = view.findViewById(R.id.bolling_speed)
        var bowlLine: TextView = view.findViewById(R.id.ball_line)
        var bowlLength: TextView = view.findViewById(R.id.ball_length)
        fun bind(obj: SumarryOutput1DataClass) {
            bowlingSpeed.text = obj.output
            bowlLine.text = obj.orientation
            bowlLength.text = obj.frequency
        }

    }

    companion object {
        private const val TAG = "SummaryOutput1Adapter"
    }
}