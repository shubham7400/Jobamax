package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.SummaryOutput3Adapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentAerialTravelSessionSummaryBinding
import com.app.cricketstats.kotlinclasses.NothingSelectedSpinnerAdapter
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.models.SumarryOutput3DataClass
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


class AerialTravelSessionSummaryFragment : Fragment() , View.OnClickListener{
    lateinit var binding: FragmentAerialTravelSessionSummaryBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    var isSelectedItemExist = false
    private var optionBox10 = ArrayList<String>()
    var list = ArrayList<SumarryOutput3DataClass>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAerialTravelSessionSummaryBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        val jsHashSetOutput3String = pSharedPref?.getString("jsHashSetOutput3String", "jsHashSetOutput2StringNotExist")
        val type: Type? = object : TypeToken<HashSet<SumarryOutput3DataClass>>() {}.getType()
        val SumarryOutput3DataClassHashSet: HashSet<SumarryOutput3DataClass> = Gson().fromJson(jsHashSetOutput3String, type)
        var list: ArrayList<SumarryOutput3DataClass> = ArrayList(SumarryOutput3DataClassHashSet)

        val orderedList = ArrayList<SumarryOutput3DataClass>()

        var i = 0;
        while (i < (list.size + 1)){
            list.forEach {
                if (it.sequenceNum == i){
                    orderedList.add(it)
                }
            }
            i++
        }

        val adapter = SummaryOutput3Adapter(mContext!!,
            orderedList
        )

        binding.recyclerview.adapter = adapter


        setUiAction()

        return binding.root
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        setUnit()

        val jsHashSetOutput3String = pSharedPref!!.getString("jsHashSetOutput3String", "jsHashSetOutput3StringNotExist")
       /* binding.companyNameText.text = getString(R.string.aerial_travel_distance)*/
        val gson = Gson()
        val type: Type? = object : TypeToken<HashSet<SumarryOutput3DataClass>>() {}.getType()
        val SumarryOutput3DataClassHashSet: HashSet<SumarryOutput3DataClass> = gson.fromJson(jsHashSetOutput3String, type)
        list  = ArrayList(SumarryOutput3DataClassHashSet)

        getAllOptionForOptionBox10()

        binding.backBtn.setOnClickListener(this)
        binding.battingDataAnalysisBtn.setOnClickListener(this)

        val optionBox10Adapter = ArrayAdapter(mContext!!, R.layout.spinner_item, optionBox10)
        optionBox10Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.shotTypeSpinner.adapter = NothingSelectedSpinnerAdapter(
            optionBox10Adapter,
            R.layout.on_nothing_selection,
            mContext
        )

        binding.shotTypeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (0 < position)
                {
                    binding.option10Hint.visibility = View.GONE
                }
                showHighestOutputAccordingToSelectedType()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.aerialTravelDistanceListTitle.text = getString(R.string.aerial_travel_distance_meter)
        }else{
            binding.aerialTravelDistanceListTitle.text = getString(R.string.aerial_travel_distance_miles)
        }
    }


    private fun showHighestOutputAccordingToSelectedType() {
        if (binding.shotTypeSpinner.selectedItem != null){
            var highestOutput = 0.0
            for (obj in list.iterator()){
                if (obj.type.equals(binding.shotTypeSpinner.selectedItem.toString()))
                {
                    isSelectedItemExist = true
                    if (highestOutput < obj.output3.toDouble()){
                        highestOutput = obj.output3.toDouble()
                    }
                }
            }
            if (isSelectedItemExist)
            {
                binding.highestAerialTravelDistanceValue.text = highestOutput.toString()
                binding.highestAerialTravelDistanceTitle.text = getString(R.string.aerial_travel_distance)
                isSelectedItemExist = false
            }else{
                binding.highestAerialTravelDistanceValue.text = "0.00"
                binding.highestAerialTravelDistanceTitle.text = getString(R.string.aerial_travel_distance)
            }
        }else{
            binding.highestAerialTravelDistanceValue.text = "0.00"
            binding.highestAerialTravelDistanceTitle.text = getString(R.string.aerial_travel_distance)
        }

    }

    private fun getAllOptionForOptionBox10() {
        optionBox10.clear()
        var optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        var type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        var optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        binding.option10Hint.text = optionId6DataClassObj.optionHeading
        var optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        optionId6OptionHashSet.forEach {
            optionBox10.add(it.title)
        }
    }

    override fun onClick(v: View?) {
        when(v){
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
             }

            binding.battingDataAnalysisBtn -> {
                var shotType = ""
                if (binding.shotTypeSpinner.selectedItem != null){
                    shotType = binding.shotTypeSpinner.selectedItem.toString()
                }
                val fragment =  BatSwingDataAnalysisFragment()
                val args = Bundle()
                args.putString("shotType",  shotType)
                fragment.arguments = args
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, fragment,true)
            }
        }
    }



    companion object {
        private const val TAG = "AerialTravelSessionSumm"
    }
}