package com.app.cricketstats.activity


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.billingclient.api.*
import com.android.billingclient.api.BillingClient.BillingResponseCode.OK
import com.android.billingclient.api.BillingClient.BillingResponseCode.USER_CANCELED
import com.app.cricketstats.R
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.ActivityPaymentBinding
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.stripe.android.ApiResultCallback
import com.stripe.android.Stripe
import com.stripe.android.model.Card
import com.stripe.android.model.Token
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.util.*


class PaymentActivity : AppCompatActivity(), View.OnClickListener{

    lateinit var binding: ActivityPaymentBinding
    lateinit var appPreferences: AppPreferences
    var pSharedPref: SharedPreferences? = null
    private var servicePrice: String? = null
    lateinit var billingClient: BillingClient
    private lateinit var skuDetailsResult: SkuDetailsResult
    private var skuDetails: SkuDetails? = null
    var discountedAmount = 0
    private var registrationAmount = 0
    var finalAmount = 0
    var couponId: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //   setContentView(R.layout.activity_payment)
        binding = ActivityPaymentBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        appPreferences = AppPreferences()
        appPreferences.init(this)
        pSharedPref = getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
        binding.btnPay.text = "Pay "+pSharedPref?.getInt("registrationAmount", 0)

        setUiAction()


    }

    private fun setUiAction() {
        registrationAmount = pSharedPref?.getString("registrationAmountString", "registrationAmountStringNotExist").toString().replace("\"", "").toInt()
        finalAmount = registrationAmount
        binding.btnPay.text = "Pay $ "+registrationAmount+" AUD"
        getPayment()
        setOnClickListener()
    }

    private fun getPayment() {
        val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
            if (billingResult.responseCode == OK && purchases != null) {
                for (purchase in purchases) {
                    handlePurchase( )
                }
            } else if (billingResult.responseCode == USER_CANCELED) {
                Log.i(TAG, "User cancelled purchase flow.")
            } else {
                Log.i(TAG, "onPurchaseUpdated error: ${billingResult.responseCode}")
            }
        }

        billingClient = BillingClient.newBuilder(this).setListener(purchasesUpdatedListener).enablePendingPurchases().build()

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == OK) {
                    // The BillingClient is ready. You can query purchases here.
                    GlobalScope.launch {
                        querySkuDetails(billingClient)
                    }
                }
            }

            override fun onBillingServiceDisconnected() {
                Log.i(TAG, "onBillingServiceDisconnected: ")
            }
        })


    }

    private fun handlePurchase( ) {
        val intent = Intent(this@PaymentActivity, PersonalDetailsActivity::class.java)
        startActivity(intent)
        finish()
    }

    suspend fun querySkuDetails(billingClient: BillingClient) {
        val skuList = ArrayList<String>()
        skuList.add("cricket.improve")
        val params = SkuDetailsParams.newBuilder()
        params.setSkusList(skuList).setType(BillingClient.SkuType.INAPP)

        // leverage querySkuDetails Kotlin extension function
        skuDetailsResult = withContext(Dispatchers.IO) {
            billingClient.querySkuDetails(params.build())
        }
        Log.i(TAG, "querySkuDetails: " + skuDetailsResult.skuDetailsList + " , " + skuDetailsResult.billingResult.debugMessage + " , " + skuDetailsResult.billingResult.responseCode)
        // Process the result.
        if (!skuDetailsResult.skuDetailsList.isNullOrEmpty()){
            if(skuDetailsResult.billingResult.responseCode == OK ){
                for (skuDetailsObject in skuDetailsResult.skuDetailsList!!) {
                    skuDetails = skuDetailsObject
                    val sku = skuDetails!!.sku
                    val price = skuDetails!!.price
                    if ("cricket.improve" == sku) {
                        servicePrice = price
                     }
                }
            }
        }

    }

    private fun setOnClickListener() {
        binding.backBtn.setOnClickListener(this)
        binding.betterLink.setOnClickListener(this)
        binding.betterIndiaLink.setOnClickListener(this)
        binding.applyBtn.setOnClickListener(this)
        binding.btnPayViaGoogle.setOnClickListener(this)
        binding.btnPay.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)
    }


    private fun validateCard(cardNumber: String, cvvNumber: String, expMonth: Int, expYear: Int) {
        binding.cpCardview.visibility = View.VISIBLE
        val card: Card = Card.create(cardNumber, expMonth, expYear, cvvNumber)
        val stripe = Stripe(this, getString(R.string.stripe_key))
        stripe.createCardToken(card,
                callback = object : ApiResultCallback<Token> {
                    override fun onError(e: Exception) {
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(this@PaymentActivity, "Some thing went wrong"+e.message.toString(), Toast.LENGTH_LONG).show()
                        println("MY_TOKEN_IS error " + e.message.toString())
                    }

                    @RequiresApi(Build.VERSION_CODES.M)
                    override fun onSuccess(result: Token) {
                        sendPayment(result.id)
                    }
                       /* System.out.println("MY_TOKEN_IS result " + result.id)*/
                }
        )
    }




    @RequiresApi(Build.VERSION_CODES.M)
    private fun sendPayment(stripeToken: String) {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map["userId"] = appPreferences.uuid
        map["amount"] = finalAmount
        map["serviceToken"] = stripeToken
        if (couponId != null){
            map["couponId"] = couponId!!
        }else{
            map["couponId"] = ""
        }
        println("payment_map_is $map")
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.sendPayment(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorText = response.errorBody()
                        Toast.makeText(this@PaymentActivity, "" + errorText, Toast.LENGTH_SHORT)
                                .show()
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("Payment_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            Toast.makeText(
                                    this@PaymentActivity,
                                    "Payment Successful.",
                                    Toast.LENGTH_LONG
                            ).show()
                            appPreferences.uuid = mainObject.getJSONObject("data").optString("uuid")
                            binding.cpCardview.visibility = View.GONE
                            val intent = Intent(this@PaymentActivity, PersonalDetailsActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                    this@PaymentActivity,
                                    "problem is " + mainObject.getString("message"),
                                    Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }



    override fun onClick(v: View?) {
         when(v){
             binding.backBtn -> {
                 startActivity(Intent(this, AboutCricketStats::class.java))
                 finish()
             }
             binding.betterLink -> {
                 binding.betterLink.paintFlags = binding.betterLink.paintFlags or Paint.UNDERLINE_TEXT_FLAG
                 val intent = Intent(this, WebViewActivity::class.java)
                 intent.putExtra("url", "https://www.forcetrainbetter.com")
                 startActivity(intent)
             }
             binding.betterIndiaLink -> {
                 binding.betterIndiaLink.paintFlags = binding.betterIndiaLink.paintFlags or Paint.UNDERLINE_TEXT_FLAG
                 val intent = Intent(this, WebViewActivity::class.java)
                 intent.putExtra("url", "https://www.forcetrainbetterindia.in")
                 startActivity(intent)
             }
             binding.applyBtn -> {
                 if (binding.applyCouponEdt.text != null){
                     validateCoupan()
                 }
             }
             binding.btnPayViaGoogle -> {
                 if(skuDetails != null){
                     val flowParams = BillingFlowParams.newBuilder()
                         .setSkuDetails(skuDetails!!)
                         .build()
                     val responseCode = billingClient.launchBillingFlow(this, flowParams).responseCode
                     Log.i(TAG, "initialize: response code "+responseCode)
                 }
             }
             binding.btnPay -> {
                 if ( discountedAmount == 0){
                     freeSignUpSendPayment()
                 }else{
                     if (binding.cardInput.text.toString().isEmpty()) {
                         binding.cardInput.error = "Enter card number!"
                         binding.cardInput.requestFocus()
                      } else if (binding.monthEt.text.toString().isEmpty()) {
                         binding.monthEt.error = "Enter month!"
                         binding.monthEt.requestFocus()
                      } else if (binding.yearEt.text.toString().isEmpty()) {
                         binding.yearEt.error = "Enter year!"
                         binding.yearEt.requestFocus()
                      } else if (binding.cvvEt.text.toString().isEmpty()) {
                         binding.cvvEt.error = "Enter cvv!"
                         binding.cvvEt.requestFocus()
                      } else{
                         val cardNumber: String = binding.cardInput.text.toString()
                         val cvvNumber: String = binding.cvvEt.text.toString()
                         val expMonth: Int = Integer.parseInt(binding.monthEt.text.toString())
                         val expYear: Int = Integer.parseInt(binding.yearEt.text.toString())
                         validateCard(cardNumber, cvvNumber, expMonth, expYear)
                     }

                 }
             }
             binding.backBtn -> {
                 super.onBackPressed()
             }
         }
    }

    private fun freeSignUpSendPayment() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map["userId"] = appPreferences.uuid
        map["amount"] = 0
        map["serviceToken"] = ""
        if (couponId != null){
            map["couponId"] = couponId!!
        }else{
            map["couponId"] = ""
        }
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.sendPayment(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorText = response.errorBody()
                        Toast.makeText(this@PaymentActivity, "" + errorText, Toast.LENGTH_SHORT)
                                .show()
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("Payment_RESPONSEEI", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            Toast.makeText(
                                    this@PaymentActivity,
                                    "Payment Successful.",
                                    Toast.LENGTH_LONG
                            ).show()
                            appPreferences.uuid = mainObject.getJSONObject("data").optString("uuid")
                            binding.cpCardview.visibility = View.GONE
                            val intent = Intent(this@PaymentActivity, PersonalDetailsActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                    this@PaymentActivity,
                                    "problem is " + mainObject.getString("message"),
                                    Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun validateCoupan() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map["code"] = binding.applyCouponEdt.text.toString()
        map["amount"] = registrationAmount
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.applyCoupon(map).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorText = response.errorBody()
                        Toast.makeText(this@PaymentActivity, "fdfd$errorText", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("APPLY_COUPON_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.applyCouponEdt.visibility = View.GONE
                            binding.applyBtn.visibility = View.GONE
                            binding.voucherAppliedTv.visibility = View.VISIBLE
                            binding.couponBorderedLayout.background = null
                            couponId = mainObject.getJSONObject("data").optString("couponId").toInt()
                            discountedAmount = mainObject.getJSONObject("data").optString("discountAmount").toInt()
                            if (discountedAmount == 0){
                                binding.cardLinearLayout.visibility = View.GONE
                                binding.orTextview.visibility = View.GONE
                                binding.btnPayViaGoogle.visibility = View.GONE
                                binding.btnPay.text = getString(R.string.sign_up_for_free)
                            }else{
                                binding.cardLinearLayout.visibility = View.VISIBLE
                                binding.orTextview.visibility = View.VISIBLE
                                binding.btnPayViaGoogle.visibility = View.VISIBLE
                                binding.btnPay.text = "Pay $ "+discountedAmount+" AUD"
                            }
                            finalAmount =  discountedAmount
                            binding.cpCardview.visibility = View.GONE
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                this@PaymentActivity,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }



    companion object {
        private const val TAG = "PaymentActivity"
    }
}