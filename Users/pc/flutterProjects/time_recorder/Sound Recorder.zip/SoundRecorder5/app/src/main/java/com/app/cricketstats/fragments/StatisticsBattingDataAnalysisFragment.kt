package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.config.AppPreferences
 import com.app.cricketstats.databinding.FragmentStatisticsBattingDataAnalysisBinding
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type
import java.text.DecimalFormat

class StatisticsBattingDataAnalysisFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentStatisticsBattingDataAnalysisBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    var list: ArrayList<String>? = null

    val dec = DecimalFormat("####.00")
    private lateinit var heading1SelectRankingAdapter: ArrayAdapter<String>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        binding = FragmentStatisticsBattingDataAnalysisBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.root
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        setOnClickListener()

        initializeShotTypeDropdown()
        setUnit()

        binding.shotTypeSelectionSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })


        initializeRanking2AndRanking3DropDown()

        callApiToDataAnalysis()

    }



    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_km_hr)
        }else{
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_mile_hr)
        }
    }
    private fun initializeRanking2AndRanking3DropDown() {
        heading1SelectRankingAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, arrayListOf(
            "World",
            "Age",
            "Club",
            "Competition",
            "State/Province/County",
            "Country"
        ))
        heading1SelectRankingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.ranking2ForHeading1.adapter = heading1SelectRankingAdapter
        binding.ranking3ForHeading1.adapter = heading1SelectRankingAdapter

        binding.ranking2ForHeading1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.ranking3ForHeading1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

    }


    private fun initializeShotTypeDropdown() {
        val optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        list = ArrayList<String>()
        optionId6OptionHashSet.forEach {
            list!!.add(it.title)
        }

        val heading1SelectionAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, list!!)
        heading1SelectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.shotTypeSelectionSpinner.adapter = heading1SelectionAdapter

        /*var shotType = requireArguments()!!.getString("shotType")
        if (shotType != ""){
            binding.shotTypeSelectionSpinner.setSelection(list!!.indexOf(shotType))
        }*/
    }

    private fun setOnClickListener() {
        binding.backBtn.setOnClickListener(this)
        binding.heading1ViewListingForRanking2Btn.setOnClickListener(this)
        binding.heading1ViewListingForRanking3Btn.setOnClickListener(this)
    }

    private fun callApiToDataAnalysis() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map["userId"] = appPreferences.uuid
        map["selectedMaterial"] = binding.shotTypeSelectionSpinner.selectedItem.toString()
        map["selectedRanking2"] = binding.ranking2ForHeading1.selectedItem.toString()
        map["selectedRanking3"] = binding.ranking3ForHeading1.selectedItem.toString()
        map["isImperial"] = appPreferences.isImperial
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getDataAnalysisOne(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorBody = response.errorBody()
                        val errorText = errorBody?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("DATA_ANALYSIS_ONE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            val obj = mainObject.getJSONObject("data")
                            getInitializeHeading1(obj.opt("baseLine"), obj.opt("average"), obj.opt("peak"), obj.opt("highestOutput3"), obj.opt("ranking2"), obj.opt("ranking3"))
                            Log.i( TAG, "onResponse: got success"+mainObject.getJSONObject("data").opt("ranking"))
                            /*var heading3Obj = mainObject.getJSONObject("data").getJSONObject("heading3")
                            getInitializeHeading3(heading3Obj.opt("baseLine"), heading3Obj.opt("average"), heading3Obj.opt("peak"))
                            var heading4Obj = mainObject.getJSONObject("data").getJSONObject("heading4")
                            getInitializeHeading4(heading4Obj.opt("baseLine"), heading4Obj.opt("average"), heading4Obj.opt("peak"),mainObject.getJSONObject("data").opt("ranking"))*/
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i( TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun getInitializeHeading1(baseLine: Any?, average: Any?, peak: Any?, highestOutput3: Any?, ranking2: Any?, ranking3: Any?) {
        binding.baselineValueTv.text = dec.format(baseLine.toString().toDouble()).toString()
        binding.averageSpeedValueTv.text = dec.format(average.toString().toDouble()).toString()
        binding.peakSpeedValueTv.text = dec.format(peak.toString().toDouble()).toString()
        binding.averagePlusMinusValueTextview.text = ((dec.format(average.toString().toDouble() - baseLine.toString().toDouble()) ).toString())
        binding.peakPlusMinusValueTextview.text = ((dec.format(peak.toString().toDouble() - baseLine.toString().toDouble()) ).toString())
        binding.ranking2Textview.text = ranking2.toString()
        binding.ranking3Textview.text = ranking3.toString()
        binding.highestAerialTravelDistanceValue.text = dec.format(highestOutput3.toString().toDouble()).toString()
    }

    override fun onClick(v: View?) {
        when(v) {
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
                /* super.onBackPressed();*/
            }
            binding.heading1ViewListingForRanking2Btn -> {

                val fragment = BatSwingViewListingFragment()
                val args = Bundle()
                args.putString("shotType",  binding.shotTypeSelectionSpinner.selectedItem.toString())
                args.putBoolean("isOutputTwo", true)
                fragment.arguments = args
                (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, fragment,true)

            }
            binding.heading1ViewListingForRanking3Btn -> {

                val fragment = BatSwingViewListingFragment()
                val args = Bundle()
                args.putString("shotType",  binding.shotTypeSelectionSpinner.selectedItem.toString())
                args.putBoolean("isOutputTwo", false)
                fragment.arguments = args
                (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, fragment,true)

            }
        }
    }

    companion object {
        private const val TAG = "StatisticsBattingDataAn"
    }
}