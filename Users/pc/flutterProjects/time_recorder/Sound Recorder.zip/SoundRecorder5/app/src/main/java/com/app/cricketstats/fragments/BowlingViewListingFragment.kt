package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
 import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.BowlingDataAnalysisViewListingAdapter
import com.app.cricketstats.config.AppPreferences
 import com.app.cricketstats.databinding.FragmentBowlingViewListingBinding
import com.app.cricketstats.models.Output1ViewListingDataClass
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class BowlingViewListingFragment : Fragment() {
    lateinit var binding: FragmentBowlingViewListingBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    private lateinit var factorAdapter: ArrayAdapter<String>
    var arrayList  = ArrayList<Output1ViewListingDataClass>()
    private var selectedRanking = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBowlingViewListingBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.root
    }

    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.bowlingSpeedPeakTitleTv.text = getString(R.string.bowling_speed_peak_km_hr)
        }else{
            binding.bowlingSpeedPeakTitleTv.text = getString(R.string.bowling_speed_peak_mile_hr)
        }
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        binding.backBtn.setOnClickListener {
            (activity as MainActivity).popFragments()
        }

        setUnit()

        val selectedFactor = requireArguments().getString("selectedFactor")
        selectedRanking = requireArguments().getString("selectedRanking").toString()



        binding.selectedFactor.text = selectedFactor


        val arrayOfFactor = arrayListOf("Straight", "Off", "Wide of off", "Wide of leg", "Leg", "Full", "Good", "Short")


        factorAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, arrayOfFactor )
        factorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerForSelectingFactor.adapter = factorAdapter

        for (factor in arrayOfFactor.iterator()){
            if (factor == selectedFactor.toString()){
                binding.spinnerForSelectingFactor.setSelection(arrayOfFactor.indexOf(factor))
            }
        }


        callApiTogetViewListingResultForOutput1()


        binding.spinnerForSelectingFactor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiTogetViewListingResultForOutput1()
                binding.selectedFactor.text = binding.spinnerForSelectingFactor.selectedItem.toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

    }



    fun callApiTogetViewListingResultForOutput1() {
        arrayList.clear()
         binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String,Any>()
        map["selectedFactor"] = binding.spinnerForSelectingFactor.selectedItem.toString()
        map["selectedRanking"] = selectedRanking
        map["selectedAgeGroup"] = ""
        map["userId"] = appPreferences.uuid
        map["isImperial"] = appPreferences.isImperial
        Log.i(TAG, "callApiTogetViewListingResultForOutput1: rrf $map")
        /*map[""] = appPreferences.uuid*/
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.viewListing(map,  appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    arrayList  = ArrayList()
                    if (response.body() == null) {
                        val errorText = response.errorBody().toString()
                        Log.i( TAG, "onResponse: rerr $errorText")
                    }
                    val res = Gson().toJson(response.body())
                    val mainObject = JSONObject(res)
                    Log.d("VIEW_LISTING", mainObject.toString())
                    if (mainObject.getBoolean("success")) {
                          binding.cpCardview.visibility = View.GONE
                        var i = 0
                        while (i < mainObject.getJSONArray("data").length() ) {
                            val obj = mainObject.getJSONArray("data").getJSONObject(i)
                            arrayList.add(Output1ViewListingDataClass(obj.opt("userId") as String, obj.opt("outputDate") as String, obj.opt("output1") as String, obj.opt("factorPercentage") as String))
                            i++
                        }
                        val bowlingDataAnalysisViewListingAdapter = BowlingDataAnalysisViewListingAdapter(arrayList)
                        binding.recyclerview.adapter = bowlingDataAnalysisViewListingAdapter
                    } else {
                         binding.cpCardview.visibility = View.GONE
                        Toast.makeText(
                            mContext,
                            "problem is " + mainObject.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                     binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                 binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }


    companion object {
        private const val TAG = "BowlingViewListingFrag"
    }

}