package com.app.cricketstats.fragments

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
  import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentEditProfileBinding
import com.app.cricketstats.kotlinclasses.NothingSelectedSpinnerAdapter
import com.app.cricketstats.models.Country
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.io.ByteArrayOutputStream


class EditProfileFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentEditProfileBinding
    var pSharedPref: SharedPreferences? = null
    var mContext: Context? = null
    private var phoneNumber: String? = ""
    lateinit var appPreferences: AppPreferences
    private val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
    private lateinit var countryListAdapter: ArrayAdapter<String>
    private var allCountryArrayList = ArrayList<String>()
    private var allCountryObjArrayList = ArrayList<Country>()
    private lateinit var genderAdapter: ArrayAdapter<String>
    private lateinit var stateTypeAdapter: ArrayAdapter<String>
    private lateinit var stateListAdapter: ArrayAdapter<String>
    private lateinit var ageAdapter: ArrayAdapter<String>
    private var listOfStateOfSelectedCountry = ArrayList<String>()
    var genderArrayList = ArrayList<String>()
    var ageArrayList = ArrayList<String>()
    var arrayListOfStateType = ArrayList<String>()
    var imageString: String = ""
    var data = JSONObject()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentEditProfileBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        if (appPreferences.profileUrl != null && appPreferences.profileUrl != ""){
            Log.i(TAG, "setUiAction: ddddf "+appPreferences.profileUrl)
            DownloadImageFromInternet(binding.roundedimag).execute(appPreferences.profileUrl)
        }

        binding.cameraIcon.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)
        binding.btnSave.setOnClickListener(this)
        setAdapterOnEachSpinner()
        setOnItemSelectedListenerOnEachSpinner()


     }



    private fun getUserInfo() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getUserInfo( appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        var errorText = response.errorBody()
                        Toast.makeText(
                                mContext,
                                "" + errorText,
                                Toast.LENGTH_SHORT
                        ).show()
                        Log.i( TAG, "onResponse: erroddr body " + errorText)
                    } else {
                        listOfStateOfSelectedCountry.clear()
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("USER_INFO_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            data = mainObject.getJSONObject("data")
                            binding.nameUser.setText( data.opt("name").toString())
                            binding.nameUser.isEnabled = false
                            binding.emailUser.setText(data.opt("email").toString())
                            binding.emailUser.isEnabled = false
                            binding.phoneUser.setText(data.opt("phoneNumber").toString())
                            binding.phoneUser.isEnabled = false
                            binding.clubOrSchoolEdt.setText(data.opt("clubOrSchoolName").toString())
                            binding.clubOrSchoolEdt.isEnabled = false
                            for (gender in genderArrayList.iterator()){
                                if (gender.toString().equals(data.opt("gender").toString())){
                                    binding.genderSpinner.setSelection(genderArrayList.indexOf(gender) + 1)
                                    break
                                }
                            }
                            binding.genderSpinner.isEnabled = false
                            for (age in ageArrayList.iterator()){
                                if (age.toString().equals(data.opt("ageGroup").toString())){
                                    binding.ageSpinner.setSelection(ageArrayList.indexOf(age) + 1)
                                    break
                                }
                            }
                            binding.ageSpinner.isEnabled = false
                            binding.competitionEdt.setText(data.opt("competition").toString())
                            binding.competitionEdt.isEnabled = false
                            for (country in allCountryArrayList.iterator()){
                                if (country.toString().equals(data.opt("country").toString())){
                                    binding.selectCountry.setSelection(allCountryArrayList.indexOf(country) + 1)
                                    for (obj in allCountryObjArrayList) {
                                        if (obj.countryName.toString().equals(binding.selectCountry.selectedItem.toString())) {
                                            getStateOfSelectedCountry(obj.shortName.toString(), data)
                                        }
                                    }
                                    break
                                }
                            }
                            binding.selectCountry.isEnabled = false
                            for (stateType in arrayListOfStateType.iterator()){
                                if (stateType.toString().equals(data.opt("stateType").toString())){
                                    binding.stateType.setSelection(arrayListOfStateType.indexOf(stateType) + 1)
                                    break
                                }
                            }
                            binding.stateType.isEnabled = false

                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                    mContext,
                                    "problem is " + mainObject.getString("message"),
                                    Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception d her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun getStateOfSelectedCountry(countryShortName: String, data: JSONObject) {
        var selectedCountryNameCode = countryShortName
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map.put("countryShortName", selectedCountryNameCode)
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getAllState(map).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        var errorText = response.errorBody()
                        Toast.makeText(
                            mContext,
                            "" + errorText,
                            Toast.LENGTH_SHORT
                        ).show()
                        Log.i( TAG, "onResponse: error body " + errorText)
                    } else {
                        listOfStateOfSelectedCountry.clear()
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("ALL_STATE_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            var i = 0
                            while (i < mainObject.getJSONArray("data").length()) {
                                listOfStateOfSelectedCountry.add(mainObject.getJSONArray("data").getJSONObject(i).getString("stateName"))
                                i++
                            }
                            stateListAdapter.notifyDataSetChanged()
                            for (state in listOfStateOfSelectedCountry.iterator()){
                                if (state.toString().equals(this@EditProfileFragment.data.opt("state").toString())){
                                    binding.state.setSelection(listOfStateOfSelectedCountry.indexOf(state) + 1)
                                    break
                                }
                            }
                            binding.state.isEnabled = false
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception isss her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }



    private fun setOnItemSelectedListenerOnEachSpinner() {
        binding.selectCountry.setOnItemSelectedListener(object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0) {
                    binding.selectCountryHint.visibility = View.GONE
                    if (binding.selectCountry.selectedItem != null) {
                        for (obj in allCountryObjArrayList) {
                            if (obj.countryName.toString().equals(binding.selectCountry.selectedItem.toString())) {
                                getStateOfSelectedCountry(obj.shortName.toString(), data)
                            }
                        }
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        binding.stateType.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.stateTypeHint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        binding.state.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.stateNameHint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        binding.genderSpinner.setOnItemSelectedListener(object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.genderHint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        binding.ageSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.ageHint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })



    }


    private fun setAdapterOnEachSpinner() {
        genderArrayList = arrayListOf<String>("Male", "Female")
        genderAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, genderArrayList)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.genderSpinner.adapter = NothingSelectedSpinnerAdapter(
            genderAdapter,
            R.layout.on_nothing_selection,
            mContext
        )

        ageArrayList = arrayListOf<String>(
            "Under 11",
            "Under 12",
            "Under 13",
            "Under 14",
            "Under 15",
            "Under 17",
            "Senior"
        )
        ageAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, ageArrayList)
        ageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.ageSpinner.adapter = NothingSelectedSpinnerAdapter(
            ageAdapter,
            R.layout.on_nothing_selection,
            mContext
        )

        getAllCountries()
        countryListAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, allCountryArrayList)
        countryListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.selectCountry.adapter = NothingSelectedSpinnerAdapter(
            countryListAdapter,
            R.layout.on_nothing_selection,
            mContext
        )

        arrayListOfStateType = arrayListOf<String>("State", "Provience", "County")
        stateTypeAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, arrayListOfStateType)
        stateTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.stateType.adapter = NothingSelectedSpinnerAdapter(
            stateTypeAdapter,
            R.layout.on_nothing_selection,
            mContext
        )


        stateListAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, listOfStateOfSelectedCountry)
        stateListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.state.adapter = NothingSelectedSpinnerAdapter(
            stateListAdapter,
            R.layout.on_nothing_selection,
            mContext
        )
    }

    private fun editProfile() {
        phoneNumber =   binding.countryCodeText.text.toString()+""+binding.phoneUser.text.toString()

        if (binding.nameUser.text.isBlank()) {
            GlobalOperation.showDialog(mContext,"Name can not be empty")
            binding.nameUser.requestFocus()
        }else if (binding.emailUser.text.isBlank() || (!binding.emailUser.text.matches(emailPattern.toRegex()))) {
            if ((!binding.emailUser.text.matches(emailPattern.toRegex())) && (!binding.emailUser.text.isBlank())){
                GlobalOperation.showDialog(mContext,"Invalid email pattern")
                binding.emailUser.requestFocus()
            }else{
                GlobalOperation.showDialog(mContext,"Email can not be empty")
                binding.emailUser.requestFocus()
            }
        }else if (phoneNumber!!.isBlank() || phoneNumber!!.matches("[a-zA-Z]+".toRegex()) || phoneNumber!!.length > 14 || phoneNumber!!.length < 10){
            if (binding.phoneUser.text.isBlank()){
                GlobalOperation.showDialog(mContext,"Phone number can not be empty")
                binding.phoneUser.requestFocus()
            }else{
                GlobalOperation.showDialog(mContext, "Invalid mobile number")
                binding.phoneUser.requestFocus()
            }
        }else if ( binding.clubOrSchoolEdt.text.isBlank()){
            GlobalOperation.showDialog(mContext, "Club or school can not be empty")
            binding.clubOrSchoolEdt.requestFocus()
        }else if (binding.competitionEdt.text.isBlank()){
            GlobalOperation.showDialog(mContext, "Please enter competition.")
            binding.competitionEdt.requestFocus()
        }else if (binding.selectCountry.selectedItem == null){
            GlobalOperation.showDialog(mContext, "Please select country.")
            binding.selectCountry.requestFocus()
        }else if (binding.stateType.selectedItem == null){
            GlobalOperation.showDialog(mContext, "Please select state type.")
            binding.stateType.requestFocus()
        }else if (binding.state.selectedItem == null){
            GlobalOperation.showDialog(mContext, "Please select state.")
            binding.state.requestFocus()
        }else if (binding.ageSpinner.selectedItem == null){
            GlobalOperation.showDialog(mContext, "Please select age.")
            binding.ageSpinner.requestFocus()
        }else if (binding.genderSpinner.selectedItem == null){
            GlobalOperation.showDialog(mContext, "Please select gender.")
            binding.ageSpinner.requestFocus()
        }else{
             phoneNumber = "+"+phoneNumber
            /*Toast.makeText(this,"phone final phone number "+phoneNumber+" ,length "+ phoneNumber!!.length,Toast.LENGTH_SHORT).show()*/
            getEditProfile()
        }


    }

    private fun getEditProfile() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map.put("name",binding.nameUser.text.toString())
        map.put("email",binding.emailUser.text.toString())
        map.put("phoneNumber",phoneNumber.toString())
        map.put("ageGroup",binding.ageSpinner.selectedItem.toString())
        map.put("gender", binding.genderSpinner.selectedItem.toString())
        map.put("clubOrSchoolName", binding.clubOrSchoolEdt.text.toString())
        map.put("competition", binding.competitionEdt.text.toString())
        map.put("country", binding.selectCountry.selectedItem.toString())
        map.put("state", binding.state.selectedItem.toString())
        map.put("stateType", binding.stateType.selectedItem.toString())
        map.put("userId", appPreferences.uuid)
        map.put("profile", "data:image/png;base64,"+imageString)
        System.out.println("update profileee " + map.toString())
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.updateProfile(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        var errorText = response.errorBody()
                        Toast.makeText(
                            mContext,
                            "" + errorText,
                            Toast.LENGTH_SHORT
                        ).show()
                        Log.i( TAG, "onResponse: error body text " + errorText)
                    } else {
                        binding.cpCardview.visibility = View.GONE
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("EDIT_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            appPreferences.profileUrl = mainObject.getJSONObject("data").opt("profileUrl").toString()
                            Toast.makeText(
                                mContext,
                                "Profile info inserted.",
                                Toast.LENGTH_LONG
                            ).show()

                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(
                        TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }


    private fun getAllCountries() {
        binding.cpCardview.visibility = View.VISIBLE
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getAllCountries().enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        var errorText = response.errorBody()
                        Log.i(Companion.TAG, "onResponse: error body " + errorText)
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("ALL_COUNTRY_RESPONSE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            var i = 0
                            while (i < mainObject.getJSONArray("data").length()) {
                                var obj = mainObject.getJSONArray("data").getJSONObject(i)
                                allCountryArrayList.add(obj.getString("countryName"))
                                allCountryObjArrayList.add(
                                    Country(
                                        obj.getString("countryName"), obj.getString(
                                            "shortName"
                                        )
                                    )
                                )
                                i++
                            }
                            countryListAdapter.notifyDataSetChanged()
                            getUserInfo()

                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(Companion.TAG, "onResponse: exception isss her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != AppCompatActivity.RESULT_CANCELED) {
            when (requestCode) {
                0 -> if (resultCode == AppCompatActivity.RESULT_OK && data != null) {
                    val selectedImage = data.extras!!["data"] as Bitmap?
                    binding.roundedimag.setImageBitmap(selectedImage)
                    val byteArrayOutputStream = ByteArrayOutputStream()
                    selectedImage!!.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
                    val imageBytes: ByteArray = byteArrayOutputStream.toByteArray()
                    imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT)
                }
                1 -> if (resultCode == AppCompatActivity.RESULT_OK && data != null) {
                    val selectedImage: Uri? = data.data
                    val bitmap = MediaStore.Images.Media.getBitmap(mContext!!.contentResolver, selectedImage)
                    binding.roundedimag.setImageBitmap(bitmap )
                    val byteArrayOutputStream = ByteArrayOutputStream()
                    bitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
                    val imageBytes: ByteArray = byteArrayOutputStream.toByteArray()
                    imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT)
                }
            }
        }
    }

    fun dialogToTakeImage( ) {
        val dialog = Dialog(mContext!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_layout_to_take_picture)
        val camera = dialog.findViewById<TextView>(R.id.camera) as TextView
        camera.setOnClickListener {
            val takePicture = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
             startActivityForResult(takePicture, 0)
            dialog.dismiss()
        }
        val gallary = dialog.findViewById<TextView>(R.id.gallary) as TextView
        gallary.setOnClickListener {
            val pickPhoto = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
             startActivityForResult(pickPhoto, 1)
            dialog.dismiss()
        }
        val cancel = dialog.findViewById<TextView>(R.id.cancel) as TextView
        cancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onClick(v: View?) {
         when(v) {
             binding.btnSave -> {
                 editProfile()
             }
             binding.cameraIcon -> {
                 dialogToTakeImage( )
             }
             binding.backBtn -> {
                 (activity as MainActivity).popFragments()
                /* requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, ProfileFragment()*//*, "profile_fragment"*//*).addToBackStack( "tag" ).commit();*/
             }
         }
    }

    companion object {
        private const val TAG = "EditProfileFragment"
    }



    private inner class DownloadImageFromInternet(var imageView: ImageView) : AsyncTask<String, Void, Bitmap?>() {
        override fun doInBackground(vararg urls: String): Bitmap? {
            val imageURL = urls[0]
            var image: Bitmap? = null
            try {
                val `in` = java.net.URL(imageURL).openStream()
                image = BitmapFactory.decodeStream(`in`)
            }
            catch (e: Exception) {
                Log.e("Error Message", e.message.toString())
                e.printStackTrace()
            }
            return image
        }
        override fun onPostExecute(result: Bitmap?) {
            imageView.setImageBitmap(result)
        }
    }


}