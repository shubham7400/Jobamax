package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.SummaryOutput1Adapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentBowlingSessionSummaryBinding
import com.app.cricketstats.models.SumarryOutput1DataClass
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.text.DecimalFormat

class BowlingSessionSummaryFragment : Fragment() , View.OnClickListener{
    lateinit var binding: FragmentBowlingSessionSummaryBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    val dec = DecimalFormat("0.00")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentBowlingSessionSummaryBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)


        val jsHashSetOutput1String = pSharedPref?.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
        val type: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.type
        val SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = Gson().fromJson(jsHashSetOutput1String, type)
        val list: List<SumarryOutput1DataClass> = ArrayList(SumarryOutput1DataClassHashSet)
        val orderedList = ArrayList<SumarryOutput1DataClass>()

        var i = 0;
        while (i < (list.size + 1)){
            list.forEach {
                if (it.sequenceNum == i){
                    orderedList.add(it)
                }
            }
            i++
        }

        val adapter = SummaryOutput1Adapter(mContext!!,
            orderedList
        )
        binding.recyclerview.adapter = adapter

        setUiAction()

        return binding.root
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        binding.backBtn.setOnClickListener(this)
        binding.summaryOutput1DataAnalysisBtn.setOnClickListener(this)

        val jsHashSetOutput1String = pSharedPref!!.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
        binding.companyNameText.text = getString(R.string.session_bowling_outputs)
        val gson = Gson()
        val type: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.type
        val SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = gson.fromJson(jsHashSetOutput1String, type)
        val list: ArrayList<SumarryOutput1DataClass> = ArrayList(SumarryOutput1DataClassHashSet)
        getPercentageOfFrequency(list)
        getPercentageOfOrientation(list)
        getHeighestAndAverageOutput(list)

        setUnit()

    }



    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.bowlingSpeedTitle.text = getString(R.string.bowling_speed_km_hr)
            binding.bowlingSpeed.text = getString(R.string.bowling_speed_km_hr)
           /* binding.averageSpeed.text = getString(R.string.average_speed_km_hr)*/
        }else{
            binding.bowlingSpeedTitle.text = getString(R.string.bowling_speed_mile_hr)
            binding.bowlingSpeed.text = getString(R.string.bowling_speed_mile_hr)
            /*binding.averageSpeed.text = getString(R.string.average_speed_mile_hr)*/
        }
    }

    fun getPercentageOfOrientation(list: ArrayList<SumarryOutput1DataClass>) {
        var straight = 0
        var off = 0
        var wideOfOff = 0
        var wideOfLeg = 0
        var leg = 0
        for (obj in list.iterator()) {
            if (obj.orientation == "Straight") {
                straight++
            }
            if (obj.orientation == "Off") {
                off++
            }
            if (obj.orientation == "Wide of Off") {
                wideOfOff++
            }
            if (obj.orientation == "Wide of Leg") {
                wideOfLeg++
            }
            if (obj.orientation == "Leg") {
                leg++
            }
        }

        if ((straight + off + wideOfOff + wideOfLeg + leg) != 0) {
            val aPercent = ((straight * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
            val bPercent = ((off * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
            val cPercent = ((wideOfOff * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
            val dPercent = ((wideOfLeg * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
            val ePercent = ((leg * 100) / (straight + off + wideOfOff + wideOfLeg + leg))
            binding.aPercent.text = aPercent.toString()+"%"
            binding.bPercent.text = bPercent.toString()+"%"
            binding.cPercent.text = cPercent.toString()+"%"
            binding.dPercent.text = dPercent.toString()+"%"
            binding.ePercent.text = ePercent.toString()+"%"
        } else {
            binding.aPercent.text = "0.00"+"%"
            binding.bPercent.text = "0.00"+"%"
            binding.cPercent.text = "0.00"+"%"
            binding.dPercent.text = "0.00"+"%"
            binding.ePercent.text = "0.00"+"%"
        }
    }


    private fun getHeighestAndAverageOutput(list: ArrayList<SumarryOutput1DataClass>) {
        var highestOutput = list[0].output.toDouble()
        var totalOutput = 0.0
        for (obj in list.iterator()) {
            totalOutput = totalOutput + obj.output.toDouble()
            if (highestOutput < obj.output.toDouble()) {
                highestOutput = obj.output.toDouble()
            }
        }
        Log.i(Companion.TAG, "setActionUi: total output $totalOutput")
        binding.summary1HighestOutput.text = dec.format(highestOutput).toString()
        binding.summary1AverageOutput.text = dec.format((totalOutput / list.size)).toString()
    }




    fun getPercentageOfFrequency(list: ArrayList<SumarryOutput1DataClass>) {
        var full = 0
        var good = 0
        var short = 0
        for (obj in list.iterator()) {
            if (obj.frequency == "Full") {
                full++
            }
            if (obj.frequency == "Good") {
                good++
            }
            if (obj.frequency == "Short") {
                short++
            }
        }

        if ((full + good + short) != 0) {
            val fPercent = ((full * 100) / (full + good + short))
            val gPercent = ((good * 100) / (full + good + short))
            val sPercent = ((short * 100) / (full + good + short))
            binding.fPercent.text = fPercent.toString()+"%"
            binding.gPercent.text = gPercent.toString()+"%"
            binding.sPercent.text = sPercent.toString()+"%"
        } else {
            binding.fPercent.text = "0.00"+"%"
            binding.gPercent.text = "0.00"+"%"
            binding.sPercent.text = "0.00"+"%"
        }
    }


    override fun onClick(v: View?) {
        when(v) {
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
             }

            binding.summaryOutput1DataAnalysisBtn -> {
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, BowlingDataAnalysisFragment(),true)
             }
        }
    }

    companion object {
        private const val TAG = "BowlingSessionSummaryFr"
    }
}