package com.app.cricketstats.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.cricketstats.R
import com.app.cricketstats.models.Output1ViewListingDataClass

class BowlingDataAnalysisViewListingAdapter(val list: ArrayList<Output1ViewListingDataClass>?) : RecyclerView.Adapter<BowlingDataAnalysisViewListingAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.output1_view_listing, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var obj = list!![position]
        holder.bind(obj)
    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var outputDate = view.findViewById<TextView>(R.id.outputDate)
        var output = view.findViewById<TextView>(R.id.output1)
        var factorPercentage = view.findViewById<TextView>(R.id.factorPercentage)

        fun bind(obj: Output1ViewListingDataClass) {
            Log.i(TAG, "bind: dd "+output)
            Log.i(TAG, "bind: ddff "+outputDate)
            outputDate.text = obj.outputDate
            output.text = obj.output1
            factorPercentage.text = obj.factorPercentage+"%"
        }
    }

    companion object {
        private const val TAG = "BowlingDataAnalysisView"
    }
}