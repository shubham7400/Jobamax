package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
 import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentHomeBinding
import com.app.cricketstats.kotlinclasses.NothingSelectedSpinnerAdapter
import com.app.cricketstats.models.*
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class HomeFragment : Fragment() {
    lateinit var binding: FragmentHomeBinding
    lateinit var appPreferences: AppPreferences
    var pSharedPref: SharedPreferences? = null
    var mContext: Context? = null
    var hashSetToHoldOptionBox6Obj: HashSet<OptionBox6DataClass>? = null

    private var optionId1OptionTitleArray = ArrayList<String>()
    private var optionId1MeterTitleArray = ArrayList<String>()
    private var optionId1yardTitleArray = ArrayList<String>()
    private var optionId2OptionTitleArray = ArrayList<String>()
    private var optionId3OptionTitleArray = ArrayList<String>()
    private var optionId4OptionTitleArray = ArrayList<String>()
    private var optionId5OptionTitleArray = ArrayList<String>()

    private lateinit var optionId1ArrayAdapter: ArrayAdapter<String>
    private lateinit var optionId2ArrayAdapter: ArrayAdapter<String>
    private lateinit var optionId3ArrayAdapter: ArrayAdapter<String>

    private lateinit var optionId4ArrayAdapter: ArrayAdapter<String>
    private lateinit var optionId5ArrayAdapter: ArrayAdapter<String>

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
        pSharedPref!!.edit().putString("jsHashSetOutput1String", Gson().toJson( ArrayList<SumarryOutput1DataClass>())).apply()
        pSharedPref!!.edit().putString("jsHashSetOutput2String", Gson().toJson( ArrayList<SumarryOutput2DataClass>())).apply()
        pSharedPref!!.edit().putString("jsHashSetOutput3String", Gson().toJson( ArrayList<SumarryOutput3DataClass>())).apply()

        if (GlobalOperation.isNetworkConnected(mContext)){
            setUiAction()
        }else{
            GlobalOperation.showDialog(
                mContext,
                "Please make sure that you are connected with network."
            )
        }

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        setOnItemSelectedListenerOnEachSpinner()

        binding.companyNameText.text = getString(R.string.cricket_stats)

        getAllOptions()

        initializeAllSpinner()

        if (hashSetToHoldOptionBox6Obj == null){
            hashSetToHoldOptionBox6Obj = HashSet<OptionBox6DataClass>()
        }

        binding.btnGo.setOnClickListener { goToStartRecording() }


    }


    private fun initializeAllSpinner() {
        optionId2ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId2OptionTitleArray
        )
        optionId2ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.option2.adapter = NothingSelectedSpinnerAdapter(
            optionId2ArrayAdapter,
            R.layout.on_nothing_selection,
            mContext
        )

        optionId1ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId1OptionTitleArray
        )
        optionId1ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
         binding.option1.adapter = optionId1ArrayAdapter
         binding.option1.adapter = NothingSelectedSpinnerAdapter(
             optionId1ArrayAdapter,
             R.layout.on_nothing_selection,
             mContext
         )

        optionId3ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId3OptionTitleArray
        )
        optionId3ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
         binding.option3.adapter = NothingSelectedSpinnerAdapter(
             optionId3ArrayAdapter,
             R.layout.on_nothing_selection,
             mContext
         )

        optionId4ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId4OptionTitleArray
        )
        /*optionId4ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
         binding.option4.adapter = NothingSelectedSpinnerAdapter(
             optionId4ArrayAdapter,
             R.layout.on_nothing_selection,
             mContext
         )
*/
        optionId5ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId5OptionTitleArray
        )
        optionId5ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
         binding.option5.adapter = NothingSelectedSpinnerAdapter(
             optionId5ArrayAdapter,
             R.layout.on_nothing_selection,
             mContext
         )
    }

    private fun goToStartRecording() {
        try {
            if (binding.option1.selectedItem == null) {
                GlobalOperation.showDialog(mContext, "Please select option 1 ")
            } else if (binding.option2.selectedItem == null) {
                GlobalOperation.showDialog(mContext, "Please select option 2 ")
            } else if (binding.option3.selectedItem == null) {
                GlobalOperation.showDialog(mContext, "Please select option 3 ")
            } else if (binding.option5.selectedItem == null) {
                GlobalOperation.showDialog(mContext, "Please select option 5 ")
            } else {
                val selectedUnit = Gson().toJson(binding.option2.selectedItem.toString())
                pSharedPref!!.edit().putString("selectedUnit", selectedUnit).apply()
                val startFragment = StartFragment()
                val args = Bundle()
                args.putString("OptionId1SelectedTitle", binding.option1.selectedItem.toString())
                args.putString("OptionId2SelectedTitle", binding.option2.selectedItem.toString())
                args.putString("OptionId3SelectedTitle", binding.option3.selectedItem.toString())
                args.putString("OptionId5SelectedTitle", binding.option5.selectedItem.toString())
                startFragment.arguments = args
                (requireActivity() as MainActivity).pushFragments(
                    (requireActivity() as MainActivity).TAB_HOME,
                    startFragment,
                    true
                )
                /*requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, startFragment*//*, "start_fragment"*//*).addToBackStack("start_fragment").commit();*/
            }
        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message ?: "something went wrong", Toast.LENGTH_LONG).show()
        }
    }


    private fun setOnItemSelectedListenerOnEachSpinner() {
        binding.option2.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.option2Hint.visibility = View.GONE
                if (binding.option2.selectedItem != null) {
                    changeOptionId1DataInSpinner()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        binding.option1.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.option1Hint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        binding.option3.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.option3Hint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })


        binding.option5.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0)
                    binding.option5Hint.visibility = View.GONE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
    }

    fun changeOptionId1DataInSpinner() {
        if ( binding.option2.selectedItem != null) {
            if ( binding.option2.selectedItem.toString() == "Metric") {
                optionId1ArrayAdapter = ArrayAdapter(
                    mContext!!,
                    R.layout.spinner_item,
                    optionId1MeterTitleArray
                )
                optionId1ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                 binding.option1.adapter = NothingSelectedSpinnerAdapter(
                     optionId1ArrayAdapter,
                     R.layout.on_nothing_selection,
                     mContext
                 )
            } else {
                optionId1ArrayAdapter = ArrayAdapter(
                    mContext!!,
                    R.layout.spinner_item,
                    optionId1yardTitleArray
                )
                optionId1ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.option1.adapter = NothingSelectedSpinnerAdapter(
                    optionId1ArrayAdapter,
                    R.layout.on_nothing_selection,
                    mContext
                )
            }
        }
    }


    @RequiresApi(Build.VERSION_CODES.KITKAT_WATCH)
    private fun getAllOptions() {
        clearAllData()
        binding.cpCardview.visibility = View.VISIBLE
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getAllOptions(appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    val res = Gson().toJson(response.body())
                    val mainObject = JSONObject(res)
                    Log.d("GET_ALL_OPTIONS", mainObject.toString())
                    if (mainObject.getBoolean("success")) {
                        binding.cpCardview.visibility = View.GONE
                        val data = mainObject.getJSONArray("data")
                        var i = 0
                        while (i < data.length()) {
                            val obj = data.getJSONObject(i)
                            when (obj.opt("optionId").toString().toInt()) {
                                1 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0

                                    binding.option1Hint.text = heading

                                    while (j < option.length()) {
                                        var optionObj = option.getJSONObject(j)
                                        optionId1OptionTitleArray.add(
                                            optionObj.opt("title").toString()
                                        )
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }

                                    val meterHashSet = HashSet<MeterDataClass>()
                                    val meters = obj.getJSONArray("meters")
                                    var k = 0
                                    while (k < meters.length()) {
                                        val metersObj = meters.getJSONObject(k)
                                        optionId1MeterTitleArray.add(
                                            metersObj.opt("title").toString()
                                        )
                                        meterHashSet.add(
                                            MeterDataClass(
                                                metersObj.opt("title").toString(), metersObj.opt(
                                                    "value"
                                                ).toString()
                                            )
                                        )
                                        k++
                                    }
                                    val yardHashSet = HashSet<YardDataClass>()
                                    val yards = obj.getJSONArray("yards")
                                    var l = 0
                                    while (l < yards.length()) {
                                        val yardsObj = yards.getJSONObject(l)
                                        optionId1yardTitleArray.add(
                                            yardsObj.opt("title").toString()
                                        )
                                        yardHashSet.add(
                                            YardDataClass(
                                                yardsObj.opt("title").toString(), yardsObj.opt(
                                                    "value"
                                                ).toString()
                                            )
                                        )
                                        l++
                                    }
                                    optionId1ArrayAdapter.notifyDataSetChanged()
                                    val optionId1DataClassObj = OptionId1DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet,
                                        meterHashSet,
                                        yardHashSet
                                    )
                                    val optionId1DataClassObjString = Gson().toJson(
                                        optionId1DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "optionId1DataClassObjString",
                                        optionId1DataClassObjString
                                    ).apply()
                                }
                                2 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    binding.option2Hint.text = heading
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionId2OptionTitleArray.add(
                                            optionObj.opt("title").toString()
                                        )
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    optionId2ArrayAdapter.notifyDataSetChanged()
                                    val optionId2DataClassObj = OptionId2DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId2DataClassObjString = Gson()!!.toJson(
                                        optionId2DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "optionId2DataClassObjString",
                                        optionId2DataClassObjString
                                    ).apply()
                                }
                                3 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    binding.option3Hint.text = heading
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionId3OptionTitleArray.add(
                                            optionObj.opt("title").toString()
                                        )
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    optionId3ArrayAdapter.notifyDataSetChanged()
                                    val OptionId3DataClassObj = OptionId3DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId3DataClassObjString = Gson().toJson(
                                        OptionId3DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "OptionId3DataClassObjString",
                                        optionId3DataClassObjString
                                    ).apply()
                                }
                                4 -> {
                                    val totalTimeDurToRecSound = obj.getJSONArray("option").getJSONObject(0).getDouble("value")
                                    Log.i(TAG, "onResponse: print tit "+totalTimeDurToRecSound)
                                    val totalTimeDurToRecSoundString = Gson().toJson(totalTimeDurToRecSound)
                                    pSharedPref!!.edit().putString("totalTimeDurToRecSoundString", totalTimeDurToRecSoundString).apply()
                                    /*val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    *//*binding.option4Hint.text = heading*//*
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionId4OptionTitleArray.add(
                                            optionObj.opt("title").toString()
                                        )
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    optionId4ArrayAdapter.notifyDataSetChanged()
                                    val OptionId4DataClassObj = OptionId4DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val OptionId4DataClassObjString = Gson()!!.toJson(
                                        OptionId4DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "OptionId4DataClassObjString",
                                        OptionId4DataClassObjString
                                    ).apply()*/
                                }
                                5 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    binding.option5Hint.text = heading
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionId5OptionTitleArray.add(
                                            optionObj.opt("title").toString()
                                        )
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    optionId5ArrayAdapter.notifyDataSetChanged()
                                    val optionId5DataClassObj = OptionId5DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId5DataClassObjString = Gson().toJson(
                                        optionId5DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "OptionId5DataClassObjString",
                                        optionId5DataClassObjString
                                    ).apply()
                                }
                                6 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        Log.i(TAG, "onResponse: sisee "+optionHashSet.size)
                                        j++
                                    }
                                    val optionId6DataClassObj = OptionId6DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId6DataClassObjString = Gson()!!.toJson(
                                        optionId6DataClassObj
                                    )
                                    Log.i(TAG, "onResponse: pridnt $optionHashSet")
                                    pSharedPref!!.edit().putString(
                                        "optionId6DataClassObjString",
                                        optionId6DataClassObjString
                                    ).apply()
                                }
                                7 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    val optionId7DataClassObj = OptionId7DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId7DataClassObjString = Gson().toJson(
                                        optionId7DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "optionId7DataClassObjString",
                                        optionId7DataClassObjString
                                    ).apply()
                                }
                                8 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    val OptionId8DataClassObj = OptionId8DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId8DataClassObjString = Gson().toJson(
                                        OptionId8DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "OptionId8DataClassObjString",
                                        optionId8DataClassObjString
                                    ).apply()
                                }
                                9 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    val optionId9DataClassObj = OptionId9DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId9DataClassObjString = Gson().toJson(
                                        optionId9DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "optionId9DataClassObjString",
                                        optionId9DataClassObjString
                                    ).apply()
                                }
                                10 -> {
                                    val optionId = obj.opt("optionId").toString()
                                    val heading = obj.opt("optionHeading").toString()
                                    val optionHashSet = HashSet<OptionDataClass>()
                                    val option = obj.getJSONArray("option")
                                    var j = 0
                                    while (j < option.length()) {
                                        val optionObj = option.getJSONObject(j)
                                        optionHashSet.add(
                                            OptionDataClass(
                                                optionHashSet.size,
                                                optionObj.opt("optionValueId").toString(),
                                                optionObj.opt(
                                                    "title"
                                                ).toString(),
                                                optionObj.opt("value").toString(),
                                                optionObj.opt(
                                                    "factor1"
                                                ).toString(),
                                                optionObj.opt("factor2").toString()
                                            )
                                        )
                                        j++
                                    }
                                    val optionId10DataClassObj = OptionId10DataClass(
                                        optionId,
                                        heading,
                                        optionHashSet
                                    )
                                    val optionId10DataClassObjString = Gson().toJson(
                                        optionId10DataClassObj
                                    )
                                    pSharedPref!!.edit().putString(
                                        "optionId10DataClassObjString",
                                        optionId10DataClassObjString
                                    ).apply()
                                }
                            }
                            i++
                        }

                        val objectOfInputValues = mainObject.getJSONObject("inputAndroidValues")
                        val objectOfInputValuesDataClass = InputValuesDataClass(
                            objectOfInputValues.opt("minDB1").toString(),
                            objectOfInputValues.opt("maxDB1").toString(),
                            objectOfInputValues.opt("minFrequency1").toString(),
                            objectOfInputValues.opt("maxFrequency1").toString(),
                            objectOfInputValues.opt("soundEndDuration").toString(),
                           /* objectOfInputValues.opt("minDB2").toString(),
                            objectOfInputValues.opt("maxDB2").toString(),
                            objectOfInputValues.opt("minFrequency2").toString(),
                            objectOfInputValues.opt("maxFrequency2").toString(),*/
                            objectOfInputValues.opt("soundDurationFromStartButton").toString().toDouble())
                        val objectOfInputValuesDataClassString = Gson()!!.toJson(
                            objectOfInputValuesDataClass
                        )
                        pSharedPref!!.edit().putString(
                            "objectOfInputValuesDataClassString",
                            objectOfInputValuesDataClassString
                        ).apply()


                    } else {
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(
                            mContext,
                            "problem is " + mainObject.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                        Log.i(Companion.TAG, "onResponse: ok here")
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(Companion.TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })

    }

    private fun clearAllData() {
        optionId1OptionTitleArray.clear()
        optionId1MeterTitleArray.clear()
        optionId1yardTitleArray.clear()
        optionId2OptionTitleArray.clear()
        optionId3OptionTitleArray.clear()
        optionId4OptionTitleArray.clear()
        optionId5OptionTitleArray.clear()
    }


    companion object {
        private const val TAG = "HomeFragment"
    }
}

