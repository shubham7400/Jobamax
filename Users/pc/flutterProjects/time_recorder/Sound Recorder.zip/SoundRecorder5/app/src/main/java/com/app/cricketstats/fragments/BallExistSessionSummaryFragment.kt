package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.SummaryOutput2Adapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentBallExistSessionSummaryBinding
import com.app.cricketstats.kotlinclasses.NothingSelectedSpinnerAdapter
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.models.SumarryOutput2DataClass
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


class BallExistSessionSummaryFragment : Fragment() , View.OnClickListener{
    lateinit var binding: FragmentBallExistSessionSummaryBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    private var materialTypeList = ArrayList<String>()
    var list: ArrayList<SumarryOutput2DataClass>? = null
    var isSelectedItemExist = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        binding = FragmentBallExistSessionSummaryBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        val jsHashSetOutput2String = pSharedPref?.getString("jsHashSetOutput2String", "jsHashSetOutput2StringNotExist")
        val type: Type? = object : TypeToken<HashSet<SumarryOutput2DataClass>>() {}.type
        val SumarryOutput2DataClassHashSet: HashSet<SumarryOutput2DataClass> = Gson().fromJson(jsHashSetOutput2String, type)
        var list: ArrayList<SumarryOutput2DataClass> = ArrayList<SumarryOutput2DataClass>(SumarryOutput2DataClassHashSet)

        val orderedList = ArrayList<SumarryOutput2DataClass>()

        var i = 0;
        while (i < (list.size + 1)){
            list.forEach {
                if (it.sequenceNum == i){
                    orderedList.add(it)
                }
            }
            i++
        }

        val adapter = SummaryOutput2Adapter(mContext!!,
            orderedList
        )
        binding.recyclerview.adapter = adapter

        setUiAction()


        return binding.root
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        setUnit()

        var jsHashSetOutput2String = pSharedPref!!.getString("jsHashSetOutput2String", "jsHashSetOutput2StringgNotExist").toString()
        binding.companyNameText.text = getString(R.string.session_batting_Outputs)
        var gson = Gson()
        var type: Type? = object : TypeToken<HashSet<SumarryOutput2DataClass>>() {}.getType()
        var SumarryOutput2DataClassHashSet: HashSet<SumarryOutput2DataClass> = gson.fromJson(jsHashSetOutput2String, type)
        list  = ArrayList<SumarryOutput2DataClass>(SumarryOutput2DataClassHashSet)


        setOnClickListener()

        setMaterailTypedropdown()

    }

    private fun setOnClickListener() {
        binding.backBtn.setOnClickListener(this)
        binding.output2Btn.setOnClickListener(this)
        binding.output4Btn.setOnClickListener(this)
    }

    private fun setMaterailTypedropdown() {
        val optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        binding.option9Hint.text = optionId6DataClassObj.optionHeading
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        optionId6OptionHashSet.forEach {
            materialTypeList.add(it.title)
        }

        var materialTypeAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, materialTypeList)
        materialTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.materialTypeDropdown.adapter = NothingSelectedSpinnerAdapter(
                materialTypeAdapter,
                R.layout.on_nothing_selection,
                mContext
        )
        binding.materialTypeDropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position > 0) {
                    binding.option9Hint.visibility = View.GONE
                }
                showHighestOutputAccordingToSelectedType()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_km_hr)
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_km_hr)
        }else{
            binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_mile_hr)
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_mile_hr)
        }
    }


    private fun showHighestOutputAccordingToSelectedType() {
        if (binding.materialTypeDropdown.selectedItem != null){
            var highestBatSwingSpeed = 0.0
            var highestBallExitSpeed = 0.0
            for (obj in list!!.iterator()){
                if (obj.type.equals(binding.materialTypeDropdown.selectedItem.toString()))
                {
                    highestBatSwingSpeed = obj.output2.toDouble()
                    highestBallExitSpeed = obj.output4.toDouble()
                }
            }
            for (obj in list!!.iterator()){
                if (obj.type == binding.materialTypeDropdown.selectedItem.toString())
                {
                    isSelectedItemExist = true
                    if (highestBatSwingSpeed < obj.output2.toDouble()){
                        highestBatSwingSpeed = obj.output2.toDouble()
                        highestBallExitSpeed = obj.output4.toDouble()
                    }
                }
            }
            if (isSelectedItemExist)
            {
                binding.highestBatSwingSpeedValue.text = highestBatSwingSpeed.toString()
                binding.highestBallExitSpeedValue.text = highestBallExitSpeed.toString()
                isSelectedItemExist = false
            }else{
                binding.highestBatSwingSpeedValue.text = "0.00"
                binding.highestBallExitSpeedValue.text = "0.00"
            }
        }else{
            binding.highestBatSwingSpeedValue.text = "0.00"
            binding.highestBallExitSpeedValue.text = "0.00"
        }
    }

    override fun onClick(v: View?) {
        when(v) {
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
                /* super.onBackPressed();*/
            }

            binding.output2Btn -> {
                var selectedItem = ""
                if (binding.materialTypeDropdown.selectedItem == null){
                    selectedItem = ""
                }else{
                    selectedItem = binding.materialTypeDropdown.selectedItem.toString()
                }

                val fragment =  BatSwingDataAnalysisFragment()
                val args = Bundle()
                args.putString("shotType",  selectedItem)
                args.putBoolean("isOutputTwo", true)
                fragment.arguments = args
                (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_HOME, fragment,true)
            }

            binding.output4Btn -> {
                var selectedItem = ""
                if (binding.materialTypeDropdown.selectedItem == null){
                    selectedItem = ""
                }else{
                    selectedItem = binding.materialTypeDropdown.selectedItem.toString()
                }

                val fragment =  BatSwingBowlingDataAnalysisFragment()
                val args = Bundle()
                args.putString("shotType",  selectedItem)
                args.putBoolean("isOutputTwo", false)
                fragment.arguments = args
                (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_HOME, fragment,true)
            }
        }
    }


    companion object {
        private const val TAG = "BallExistSessionSummary"
    }
}