package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
  import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentBatSwingBowlingDataAnalysisBinding
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type
import java.text.DecimalFormat

class BatSwingBowlingDataAnalysisFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentBatSwingBowlingDataAnalysisBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    var list: ArrayList<String>? = null

    val dec = DecimalFormat("####.00")
    private lateinit var heading1SelectRankingAdapter: ArrayAdapter<String>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentBatSwingBowlingDataAnalysisBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        binding.veiwSessionSummaries.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)

        setUnit()
        initializeRankingDropDown()
        initializeShotTypeDropdown()
        callApiToDataAnalysis()

    }



    private fun initializeShotTypeDropdown() {
        val optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        list = ArrayList<String>()
        optionId6OptionHashSet.forEach {
            list!!.add(it.title)
        }

        val heading1SelectionAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, list!!)
        heading1SelectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.shotTypeSelectionSpinner.adapter = heading1SelectionAdapter

       /* var shotType = requireArguments().getString("shotType")
        if (shotType != ""  && shotType != null){
            binding.shotTypeSelectionSpinner.setSelection(list!!.indexOf(shotType))
        }
*/
        binding.shotTypeSelectionSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
    }

    private fun callApiToDataAnalysis() {
        binding.cpCardview.visibility = View.VISIBLE
        var map = HashMap<String, Any>()
        map["userId"] = appPreferences.uuid
        map["selectedMaterial"] = binding.shotTypeSelectionSpinner.selectedItem.toString()
        map["selectedRanking"] = binding.ranking2ForHeading1.selectedItem.toString()
        map["isImperial"] = appPreferences.isImperial
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        Log.i(TAG, "callApiToDataAnalysis: disks $map")
        call.getDataAnalysisThree(map, appPreferences.token).enqueue(object :
            retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorBody = response.errorBody()
                        val errorText = errorBody?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                        Log.i(TAG, "onResponse: djvu $errorText")
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("DATA_ANALYSIS_THREE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            val obj = mainObject.getJSONObject("data")
                            getInitializeHeading1(
                                obj.opt("baseLine"),
                                obj.opt("average"),
                                obj.opt("peak"),
                                obj.opt("ranking")
                            )
                            Log.i(
                                Companion.TAG,
                                "onResponse: got success" + mainObject.getJSONObject("data")
                                    .opt("ranking")
                            )
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(Companion.TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun initializeRankingDropDown() {
        heading1SelectRankingAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, arrayListOf(
            "World",
            "Age",
            "Club",
            "Competition",
            "State/Provience/County",
            "Country"
        ))
        heading1SelectRankingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.ranking2ForHeading1.adapter = heading1SelectRankingAdapter

        binding.ranking2ForHeading1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun getInitializeHeading1(baseLine: Any?, average: Any?, peak: Any? , ranking: Any?) {
        binding.averageSpeedValueTv.text = dec.format(average.toString().toDouble()).toString()
        binding.peakSpeedValueTv.text = dec.format(peak.toString().toDouble()).toString()
        binding.averagePlusMinusValueTextview.text = ((dec.format(average.toString().toDouble() - baseLine.toString().toDouble())).toString())
        binding.peakPlusMinusValueTextview.text = ((dec.format(peak.toString().toDouble() - baseLine.toString().toDouble())).toString())
        binding.ranking2Textview.text = ranking.toString()
    }

    private fun setUnit() {
        if (!appPreferences.isImperial){
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_km_hr)
        }else {
            binding.ballExitSpeedTitleTv.text = getString(R.string.ball_exit_speed_mile_hr)
        }
    }

    override fun onClick(v: View?) {
        when(v){
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
            }
            binding.veiwSessionSummaries -> {

                val fragment = BallExitDataAnalysisViewListing()
                val args = Bundle()
                args.putString("shotType",  binding.shotTypeSelectionSpinner.selectedItem.toString())
                args.putBoolean("isOutputTwo", false)
                fragment.arguments = args
                (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_HOME, fragment,true)
             }
        }
    }


    companion object {
        private const val TAG = "BatSwingBowlingDataAnal"
    }
}