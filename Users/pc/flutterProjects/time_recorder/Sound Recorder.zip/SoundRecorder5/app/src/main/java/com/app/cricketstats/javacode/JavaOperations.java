package com.app.cricketstats.javacode;

import android.util.Log;

import static java.lang.Math.log10;

public class JavaOperations {
    private static double highestDecibel = 0;
    private static double frequencyCorrespondingToHeightstDecibel = 0;
    private static double time = 0;

    //convert short to byte
    public byte[] short2byte(short[] sData) {
        int shortArrsize = sData.length;
        byte[] bytes = new byte[shortArrsize * 2];
        for (int i = 0; i < shortArrsize; i++) {
            bytes[i * 2] = (byte) (sData[i] & 0x00FF);
            bytes[(i * 2) + 1] = (byte) (sData[i] >> 8);
            sData[i] = 0;
        }
        return bytes;
    }

    private static final String TAG = "JavaOperations";
}
