package com.app.cricketstats.models

data class SumarryOutput2DataClass(val sequenceNum: Int, val output2: String,val type: String, val output4: String)