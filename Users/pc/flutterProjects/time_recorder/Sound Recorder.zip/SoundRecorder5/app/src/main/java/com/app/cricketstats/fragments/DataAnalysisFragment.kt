package com.app.cricketstats.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.databinding.FragmentDataAnalysisBinding

class DataAnalysisFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentDataAnalysisBinding
    var mContext: Context? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentDataAnalysisBinding.inflate(inflater, container, false)
        setUiAction()

        mContext = requireContext()

        return binding.getRoot()
    }

    private fun setUiAction() {
         binding.coachesFrameLayout.setOnClickListener(this)
         binding.statisticsFrameLayout.setOnClickListener(this)

    }




    override fun onClick(v: View?) {
         when(v) {
             binding.coachesFrameLayout -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, VeiwClubStaticsFragment(),true)
              }
             binding.statisticsFrameLayout -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_DATA_ANALYSIS, StatisticsFragment(),true)
             }
         }
    }

}