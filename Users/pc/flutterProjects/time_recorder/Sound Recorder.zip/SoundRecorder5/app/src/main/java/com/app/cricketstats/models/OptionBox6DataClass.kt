package com.app.cricketstats.models

data class OptionBox6DataClass (val title: String, val factor1: String, val factor2: String)