package com.app.cricketstats.models

data class UserDataClass(val id: String, val name: String, val uuid: String, val phoneNumber: String)