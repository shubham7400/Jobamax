package com.app.cricketstats.viewmodels

import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import java.util.*

class MainViewModel : ViewModel() {
    var mStacks = HashMap<String, Stack<Fragment>>()

    @JvmName("setMStacks1")
    fun setMStacks(mStacks: HashMap<String, Stack<Fragment>>) {
        this.mStacks = mStacks
    }
    @JvmName("getMStacks1")
    fun getMStacks(mStacks: HashMap<String, Stack<Fragment>>): HashMap<String, Stack<Fragment>> {
        return this.mStacks
    }
}