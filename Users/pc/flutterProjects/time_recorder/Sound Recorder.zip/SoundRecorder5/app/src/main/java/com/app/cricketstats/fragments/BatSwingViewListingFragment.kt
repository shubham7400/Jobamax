package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
  import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.Output2VeiwListingAdapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentBatSwingViewListingBinding
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.models.Output2ViewListingDataClass
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type


class BatSwingViewListingFragment : Fragment() , View.OnClickListener{
    lateinit var binding: FragmentBatSwingViewListingBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    var list: ArrayList<String>? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBatSwingViewListingBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.root
    }
    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        initializeShotTypeDropdown()
        setUnit()
        callApiViewListingOne()
        binding.backBtn.setOnClickListener(this)

        binding.shotTypeSelectionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiViewListingOne()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}

        }


    }



    private fun callApiViewListingOne() {
        binding.cpCardview.visibility = View.VISIBLE
        val map = HashMap<String, Any>()
        map["userId"] = appPreferences.uuid
        map["isOutputTwo"] = requireArguments().getBoolean("isOutputTwo")
        map["selectedAgeGroup"] = ""
        map["selectedMaterial"] = binding.shotTypeSelectionSpinner.selectedItem.toString()
        map["isImperial"] = appPreferences.isImperial
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.viewListingOne(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorBody = response.errorBody()
                        val errorText = errorBody?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("VIEW_LISTING_ONE", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            val data = mainObject.getJSONArray("data")
                            val list = ArrayList<Output2ViewListingDataClass>()
                            var i = 0
                            while (i < data.length()){
                                val obj = data.getJSONObject(i)
                                list.add(Output2ViewListingDataClass(obj.optString("userId"), obj.optString("output"), obj.optString("outputDate"), obj.optString("name")))
                                i++
                            }
                            val output2ViewListingAdapter = Output2VeiwListingAdapter(list)
                            binding.recyclerview.adapter = output2ViewListingAdapter
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun setUnit() {
        val isOutputTwo = requireArguments().getBoolean("isOutputTwo")

        if (!appPreferences.isImperial){
            if (!isOutputTwo){
                binding.batSwingSpeedTitleTv.text = getString(R.string.aerial_travel_distnace_meters)
                binding.companyNameText.text = "Aerial Travel Distance Sessions Summary" /*getString(R.string.areial_travel_distance)*/
            }else{
                binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_km_hr)
                binding.companyNameText.text = "Batting Sessions Summary"/*getString(R.string.batting_session_summary)*/
            }
        }else{
            if (!isOutputTwo){
                binding.batSwingSpeedTitleTv.text = getString(R.string.aerial_travel_distance_yard)
                binding.companyNameText.text = "Aerial Travel Distance Sessions Summary" /*getString(R.string.areial_travel_distance)*/
            }else{
                binding.batSwingSpeedTitleTv.text = getString(R.string.bat_swing_speed_mile_hr)
                binding.companyNameText.text = "Batting Sessions Summary"/*getString(R.string.batting_session_summary)*/
            }
        }
    }

    private fun initializeShotTypeDropdown() {
        val optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        list = ArrayList()
        optionId6OptionHashSet.forEach {
            list!!.add(it.title)
        }

        val heading1SelectionAdapter = ArrayAdapter(mContext!!, R.layout.spinner_item, list!!)
        heading1SelectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.shotTypeSelectionSpinner.adapter = heading1SelectionAdapter

        val shotType = requireArguments().getString("shotType")
        binding.shotTypeSelectionSpinner.setSelection(list!!.indexOf(shotType))
    }


    companion object {
        private const val TAG = "BatSwingViewListingFrag"
    }

    override fun onClick(v: View?) {
        when(v) {
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
            }
        }
    }

}