package com.app.cricketstats.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.cricketstats.R
import com.app.cricketstats.models.Output2ViewListingDataClass

class BattingDataAnalysisViewListingAdapter(val list: ArrayList<Output2ViewListingDataClass>)  : RecyclerView.Adapter<BattingDataAnalysisViewListingAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.output2_veiw_listing, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var obj = list!![position]
        holder.bind(obj)
    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var outputDate = view.findViewById<TextView>(R.id.outputDate)
        var output = view.findViewById<TextView>(R.id.output)

        fun bind(obj: Output2ViewListingDataClass) {
            outputDate.text = obj.outputDate
            output.text = obj.output
        }
    }

    companion object {
        private const val TAG = "BattingDataAnalysisView"
    }
}