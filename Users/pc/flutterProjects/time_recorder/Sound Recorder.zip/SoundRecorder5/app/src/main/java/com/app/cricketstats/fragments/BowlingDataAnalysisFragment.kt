package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
  import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentBowlingDataAnalysisBinding
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.text.DecimalFormat

class BowlingDataAnalysisFragment : Fragment() , View.OnClickListener{
    lateinit var binding: FragmentBowlingDataAnalysisBinding
    var pSharedPref: SharedPreferences? = null
    val dec = DecimalFormat("####.00")
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null
    private lateinit var heading4SelectionAdapter: ArrayAdapter<String>
    private lateinit var heading4SelectRankingAdapter: ArrayAdapter<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentBowlingDataAnalysisBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        setUnit()

        binding.viewListingForHeading3Heading4Btn.setOnClickListener(this)
        binding.backBtn.setOnClickListener(this)

        heading4SelectionAdapter = ArrayAdapter(
            mContext!!, R.layout.spinner_item, arrayListOf(
                "Straight",
                "Off",
                "Wide of off",
                "Wide of leg",
                "Leg",
                "Full",
                "Good",
                "Short"
            )
        )
        heading4SelectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.selectionForHeading4Spinner.adapter = heading4SelectionAdapter

        binding.selectionForHeading4Spinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        heading4SelectRankingAdapter = ArrayAdapter(
            mContext!!, R.layout.spinner_item, arrayListOf(
                "World",
                "Age",
                "Club",
                "Competition",
                "State/Provience/County",
                "Country"
            )
        )
        heading4SelectRankingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.rankingForHeading4Spinner.adapter = heading4SelectRankingAdapter

        binding.rankingForHeading4Spinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callApiToDataAnalysis()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        callApiToDataAnalysis()

    }



    private fun setUnit() {
        if (appPreferences.isImperial == false){
            binding.bowlingSpeedTitleTv.text = getString(R.string.bowling_speed_km_hr)
        }else{
            binding.bowlingSpeedTitleTv.text = getString(R.string.bowling_speed_mile_hr)
        }
    }

    private fun callApiToDataAnalysis() {
        binding.cpCardview.visibility = View.VISIBLE
        var map = HashMap<String, Any>()
        map.put("userId", appPreferences.uuid)
        map.put("selectedFactor", binding.selectionForHeading4Spinner.selectedItem.toString())
        map.put("selectedRanking", binding.rankingForHeading4Spinner.selectedItem.toString())
        map.put("isImperial", appPreferences.isImperial)
        Log.i(TAG, "callApiToDataAnalysis: mappp "+map)
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.getDataAnalysis(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        var errorText = response.errorBody().toString()
                        Log.i(TAG, "onResponse: error is heer " + errorText)
                        binding.cpCardview.visibility = View.GONE
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("GET_DATA_ANALYSIS", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            Log.i(
                                TAG,
                                "onResponse: got success" + mainObject.getJSONObject("data").opt(
                                    "ranking"
                                )
                            )
                            var heading3Obj =
                                mainObject.getJSONObject("data").getJSONObject("heading3")
                            getInitializeHeading3(
                                heading3Obj.opt("baseLine"),
                                heading3Obj.opt("average"),
                                heading3Obj.opt(
                                    "peak"
                                )
                            )
                            var heading4Obj =
                                mainObject.getJSONObject("data").getJSONObject("heading4")
                            getInitializeHeading4(
                                heading4Obj.opt("baseLine"),
                                heading4Obj.opt("average"),
                                heading4Obj.opt(
                                    "peak"
                                ),
                                mainObject.getJSONObject("data").opt("ranking")
                            )
                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                "problem is " + mainObject.getString("message"),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i(TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }

    private fun getInitializeHeading3(baseLine: Any?, average: Any?, peak: Any?) {
        binding.heading3BaselineTextview.text = dec.format(baseLine.toString().toDouble()).toString()
        binding.heading3AverageTextview.text = dec.format(average.toString().toDouble()).toString()
        binding.heading3PeakTextview.text = dec.format(peak.toString().toDouble()).toString()
        binding.heading3PlusMinusAverageTextview.text = (dec.format(average.toString().toDouble() - baseLine.toString().toDouble())).toString()
        binding.heading3PlusMinusPeakTextview.text = (dec.format(peak.toString().toDouble() - baseLine.toString().toDouble())).toString()
    }

    private fun getInitializeHeading4(baseLine: Any?, average: Any?, peak: Any?, ranking: Any?) {
        binding.heading4PlusMinusAverageTextview.text = ((dec.format(average.toString().toDouble() - baseLine.toString().toDouble())).toString())
        binding.heading4PlusMinusPeakTextview.text = (dec.format(peak.toString().toDouble() - baseLine.toString().toDouble())).toString()
        binding.rankingForHeading4Textview.text = ranking.toString()
    }

    override fun onClick(v: View?) {
        when(v){
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
            }

            binding.viewListingForHeading3Heading4Btn -> {
                val fragment = BowlingViewListingFragment()
                val args = Bundle()
                args.putString("selectedFactor",  binding.selectionForHeading4Spinner.selectedItem.toString())
                args.putString("selectedRanking", binding.rankingForHeading4Spinner.selectedItem.toString())
                fragment.setArguments(args)
                (activity as MainActivity).pushFragments((activity as MainActivity).TAB_HOME, fragment,true)
            }
        }
    }

    companion object {
        private const val TAG = "BowlingDataAnalysisFrag"
    }

}