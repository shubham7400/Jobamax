package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.FragmentManager
 import com.app.cricketstats.R
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentUploadDataSingleUserBinding
import com.app.cricketstats.models.*
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.app.cricketstats.utils.GlobalOperation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type
import java.text.DecimalFormat
import java.util.concurrent.TimeUnit

class UploadDataSingleUserFragment : Fragment() {
    lateinit var binding: FragmentUploadDataSingleUserBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null

    val dec = DecimalFormat("####.00")


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentUploadDataSingleUserBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        uploadData()


    }


    private fun uploadData() {
        var jsHashSetOutput1String = pSharedPref!!.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
        var gson = Gson()
        var typeOutput1DataClass: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.getType()
        var SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = gson.fromJson(jsHashSetOutput1String, typeOutput1DataClass)
        var listOfOutput1DataClassObj: ArrayList<SumarryOutput1DataClass> = ArrayList<SumarryOutput1DataClass>(SumarryOutput1DataClassHashSet)

        var jsHashSetOutput2String = pSharedPref!!.getString("jsHashSetOutput2String", "jsHashSetOutput2StringgNotExist")
        var typeOutput2DataClass: Type? = object : TypeToken<HashSet<SumarryOutput2DataClass>>() {}.getType()
        var SumarryOutput2DataClassHashSet: HashSet<SumarryOutput2DataClass> = gson.fromJson(jsHashSetOutput2String, typeOutput2DataClass)
        var listOfOutput2DataClassObj  = ArrayList<SumarryOutput2DataClass>(SumarryOutput2DataClassHashSet)

        var jsHashSetOutput3String = pSharedPref!!.getString("jsHashSetOutput3String", "jsHashSetOutput3StringNotExist")
        var typeOutput3DataClass: Type? = object : TypeToken<HashSet<SumarryOutput3DataClass>>() {}.getType()
        var SumarryOutput3DataClassHashSet: HashSet<SumarryOutput3DataClass> = gson.fromJson(jsHashSetOutput3String, typeOutput3DataClass)
        val listOfOutput3DataClassObj  = ArrayList<SumarryOutput3DataClass>(SumarryOutput3DataClassHashSet)


        var optionId6DataClassObjString = pSharedPref?.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        var type: Type? = object : TypeToken<OptionId6DataClass>() {}.getType()
        var optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        var optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption

        val peakOfOutput1 = getOutput1Peak(listOfOutput1DataClassObj)
        var mapOfPeakOutputsAccordingToTitle = getPeakOutputsAccordingTotitle(listOfOutput2DataClassObj, listOfOutput3DataClassObj, optionId6OptionHashSet)

        callApiToUploadResult(peakOfOutput1, mapOfPeakOutputsAccordingToTitle)
    }

    private fun callApiToUploadResult(
        peakOfOutput1: Double,
        mapOfPeakOutputsAccordingToTitle: HashMap<String, Any>
    ) {
        var jsHashSetOutput1String = pSharedPref!!.getString("jsHashSetOutput1String", "jsHashSetOutput1StringNotExist")
        var gson = Gson()
        var type: Type? = object : TypeToken<HashSet<SumarryOutput1DataClass>>() {}.getType()
        var SumarryOutput1DataClassHashSet: HashSet<SumarryOutput1DataClass> = gson.fromJson(jsHashSetOutput1String, type)
        var list: ArrayList<SumarryOutput1DataClass> = ArrayList<SumarryOutput1DataClass>(SumarryOutput1DataClassHashSet)

        var map = mapOfPeakOutputsAccordingToTitle
        map.put("output1", peakOfOutput1)
        map.put("outputDate", TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()))
        map.put("shareWithUser", ArrayList<String>())
        map.put("userId", appPreferences.uuid)
        map.put("arrayOfFactor1", GlobalOperation.getFactor1ArrayList(list))
        map.put("arrayOfFactor2", GlobalOperation.getFactor2ArrayList(list))
        map.put("isImperial", appPreferences.isImperial)
        Log.i(TAG, "callApiToUploadResult: map final is here " + map)
        binding.cpCardview.visibility = View.VISIBLE
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.uploadResult(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        binding.cpCardview.visibility = View.GONE
                        val errorText = response.errorBody()?.string()!!
                        val errorJsonObj = JSONObject(errorText)
                        Toast.makeText(mContext, "" + errorText, Toast.LENGTH_SHORT)
                            .show()
                        Log.i( TAG, "onResponse: error bodyyy " + errorJsonObj.get("message"))
                    } else {
                        val res = Gson().toJson(response.body())
                        val mainObject = JSONObject(res)
                        Log.d("UPLOAD_RESULT", mainObject.toString())
                        if (mainObject.getBoolean("success")) {
                            binding.cpCardview.visibility = View.GONE
                            val fm = requireActivity().getSupportFragmentManager()
                            fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
                            requireActivity().getSupportFragmentManager().beginTransaction().replace(
                                R.id.fragment_container,
                                HomeFragment()/*, "edit_profile_fragment"*/
                            ).commit();

                        } else {
                            binding.cpCardview.visibility = View.GONE
                            Toast.makeText(
                                mContext,
                                " data did't get upload ",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    binding.cpCardview.visibility = View.GONE
                    Log.i( TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }


    private fun getOutput1Peak(listOfOutput1DataClassObj: ArrayList<SumarryOutput1DataClass>) : Double {
        var highestOutput = listOfOutput1DataClassObj[0].output.toDouble()
         for (obj in listOfOutput1DataClassObj.iterator()) {
             if (highestOutput < obj.output.toDouble()) {
                highestOutput = obj.output.toDouble()
            }
        }
         return dec.format(highestOutput).toDouble()
    }

    private fun getPeakOutputsAccordingTotitle(
        listOfOutput2DataClassObj: ArrayList<SumarryOutput2DataClass>,
        listOfOutput3DataClassObj: ArrayList<SumarryOutput3DataClass>,
        optionId6OptionHashSet: HashSet<OptionDataClass>
    ): HashMap<String, Any> {
        var  map = HashMap<String, Any>()
        for (option6Obj in optionId6OptionHashSet){
            var peakOutput2 = 0.0
            var peakOutput3 = 0.0
            var peakOutput4 = 0.0
            for (obj in listOfOutput2DataClassObj){
                if (option6Obj.title.toString() == obj.type)
                {
                    if (peakOutput2 < obj.output2.toDouble()){
                        peakOutput2 = obj.output2.toDouble()
                        peakOutput4 = obj.output4.toDouble()
                    }
                }
            }
            for (obj in listOfOutput3DataClassObj){
                if (option6Obj.title == obj.type){
                    if (peakOutput3 < obj.output3.toDouble()){
                        peakOutput3 = obj.output3.toDouble()
                    }
                }
            }
            map.put(option6Obj.title, arrayListOf(peakOutput2, peakOutput3, peakOutput4))
        }
        Log.i(Companion.TAG, "getPeakOutputsAccordingTotitle: map is now " + map)
        return map
    }


    companion object {
        private const val TAG = "UploadDataSingleUserFra"
    }


}