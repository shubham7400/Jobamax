package com.app.cricketstats.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.cricketstats.R
import com.app.cricketstats.fragments.UploadDataFragment
import com.app.cricketstats.models.UserDataClass

class UploadDataAdapter(
    val listOfUser: ArrayList<UserDataClass>,
    val listOfSelectedUser: ArrayList<UserDataClass>,
    val selectedUserToUploadDataAdapter: SelectedUserToUploadDataAdapter,
    val listOfSelectedUserUUID: ArrayList<String>,
    val uploadDataFragment: UploadDataFragment

) : RecyclerView.Adapter<UploadDataAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.user_list_view, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = listOfUser[position]
        holder.name.text = user.name
        holder.phoneNumber.text = user.phoneNumber
        holder.itemView.setOnClickListener {
            listOfSelectedUser.add(user)
            uploadDataFragment.binding.searchView.setQuery("", true)
            selectedUserToUploadDataAdapter.notifyDataSetChanged()
            uploadDataFragment.binding.horizontalRecyclerviewOfUserToShareData.visibility = View.VISIBLE
            uploadDataFragment.binding.verticalRecyclerviewOfUserToShareData.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
         return listOfUser.size
    }

    class ViewHolder(view: View)  : RecyclerView.ViewHolder(view) {
        var name: TextView = view.findViewById(R.id.user_name_textview)
        var phoneNumber: TextView = view.findViewById(R.id.user_phone_number_textview)
    }

}