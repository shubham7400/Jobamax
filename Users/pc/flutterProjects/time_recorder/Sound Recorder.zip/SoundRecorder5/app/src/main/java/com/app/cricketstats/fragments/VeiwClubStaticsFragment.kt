package com.app.cricketstats.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.cricketstats.activity.BattingSessionActivity
import com.app.cricketstats.activity.BowlingSessionActivity
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.databinding.FragmentVeiwClubStaticsBinding


class VeiwClubStaticsFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentVeiwClubStaticsBinding
    var mContext: Context? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentVeiwClubStaticsBinding.inflate(inflater, container, false)

            mContext = requireContext()
            setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        binding.backBtn.setOnClickListener(this)
        binding.bowlingSpeedLayout.setOnClickListener(this)
        binding.batSwingLayout.setOnClickListener(this)
        binding.aerialTravelLayout.setOnClickListener(this)
        binding.ballExitLayout.setOnClickListener(this)

    }



    override fun onClick(v: View?) {
        when(v){
            binding.backBtn->{
                (activity as MainActivity).popFragments()
                /*requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, DataAnalysisFragment(), "data_analysis_fragment").commit();*/
            }
            binding.bowlingSpeedLayout->{
                val intent = Intent(mContext, BowlingSessionActivity::class.java)
                startActivity(intent)
            }
            binding.batSwingLayout->{
                val intent = Intent(mContext, BattingSessionActivity::class.java)
                intent.putExtra("call_for","batting")
                startActivity(intent)
            }
            binding.aerialTravelLayout->{
                val intent = Intent(mContext, BattingSessionActivity::class.java)
                intent.putExtra("call_for","aerial")
                startActivity(intent)
            }
            binding.ballExitLayout->{
                val intent = Intent(mContext, BattingSessionActivity::class.java)
                intent.putExtra("call_for","bowling")
                startActivity(intent)
            }
        }
    }

}