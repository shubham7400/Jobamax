package com.app.cricketstats.activity

import android.animation.*
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.app.cricketstats.R
import com.app.cricketstats.databinding.ActivityPickerViewBinding
import com.app.cricketstats.kotlinclasses.WheelView
import com.app.cricketstats.models.OptionId6DataClass
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.util.ArrayList


class PickerViewActivity() : AppCompatActivity() {
    lateinit var binding: ActivityPickerViewBinding

    private var selectedItem = ""
    private var selectedItemPosition = 0

    var statusBarDark = false
    lateinit var pSharedPref: SharedPreferences

    private var shotTypeList = ArrayList<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Remove Open/Close Activity Animations
        overridePendingTransition(0, 0)
        binding = ActivityPickerViewBinding.inflate(layoutInflater)
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(binding.root)

        pSharedPref = this!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)
        getAllShotType()

        if (Build.VERSION.SDK_INT in 19..20) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                setWindowFlag(this, true)
            }
        }

        if (Build.VERSION.SDK_INT >= 19) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        }

        if (Build.VERSION.SDK_INT >= 21) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Show dark status bar or not
                if (statusBarDark) {
                    this.window.decorView.systemUiVisibility =
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                }
                this.window.statusBarColor = Color.TRANSPARENT
                setWindowFlag(this, false)
            }
        }


        // Fade Animation for the Semi-Transparent Black Background
        // Get the size of the size
        val mDisplay = windowManager.defaultDisplay
        val mDisplaySize = Point()
        mDisplay.getSize(mDisplaySize)
        val maxX = mDisplaySize.x
        val maxY = mDisplaySize.y

        // Set the background same as Display height
        binding.pickerviewbg.y = maxY.toFloat()
        val alpha = 85 // Set Between 0-255
        val alphaColor = ColorUtils.setAlphaComponent(Color.TRANSPARENT, alpha)
        val colorAnimation = ValueAnimator.ofObject(ArgbEvaluator(), Color.TRANSPARENT, alphaColor)
        colorAnimation.duration = 500 // milliseconds
        colorAnimation.addUpdateListener { animator -> binding.pickerviewtransbg.setBackgroundColor(Color.TRANSPARENT) }
        colorAnimation.start()


        // PickerViewActivity Customization
        binding.pickerviewbg.setBackgroundColor(ContextCompat.getColor(this, R.color.light_grey))
        binding.barview.setBackgroundColor(ContextCompat.getColor(this, R.color.colorWhite))
        // Empty click listener helps to stop the view from closing when you tap 'outside'
        binding.barview.setOnClickListener { }

        // WheelView Customization
        val wheelView = findViewById<WheelView>(R.id.wheelview)
        wheelView.selectedItemColor = Color.BLACK
        wheelView.unselectedItemColor = Color.GRAY
        wheelView.linesColor = Color.BLACK
        wheelView.itemTextSize = 25f
        //val font = ResourcesCompat.getFont(this, R.font.roboto)
        //wheelView.itemFont = font

        // Amount of items above and below the selected item
        wheelView.offset = 1


        val defaultValue = "2016"

        // Check if default value exists, if not then show the first item of on the wheelView
        if (shotTypeList.contains(defaultValue)) {
            val valueIndex = shotTypeList.indexOf(defaultValue)
            wheelView.setSelection(valueIndex)
        } else {
            wheelView.setSelection(0)
        }

        // Add the list of items to the wheelView
        wheelView.setItems(shotTypeList)

        // Set the value you see once you open the PickerView as selected item, this will change later with the onWheelViewListener
        selectedItem = wheelView.getSelectedItem

        // Set the position of the value you see once you open the PickerView as selected item position, this will change later with the onWheelViewListener
        selectedItemPosition = wheelView.getSelectedIndex

        // Returns the current selected item and position of the item after you scroll up/down
        wheelView.onWheelViewListener = object : WheelView.OnWheelViewListener() {
            override fun onSelected(selectedIndex: Int, item: String) {
                selectedItem = item
                selectedItemPosition = selectedIndex
            }
        }


        // PickerView Bar Customization
        binding.cancelbtn.setTextColor(Color.BLACK)

        // Go Back by pressing 'Cancel'
        binding.cancelbtn.setOnClickListener {
            onBackPressed()
        }

        binding.donebtn.setTextColor(Color.BLACK)


        // Returns the final selected item and position after you pressed 'Done'
        binding.donebtn.setOnClickListener {

            Log.d("Selected Item", selectedItem)

            Log.d("Selected Item Position", selectedItemPosition.toString())

            // Close PickerView
            onBackPressed()
            // Return results to the MainActivity
            returnResultsBack()

        }

        // Cancel PickerView when you press the background
        binding.pickerviewtransbg.setOnClickListener {
        }
    }

   /* private fun getAllShotType() {
        shotTypeList = ArrayList<String>()
        val optionId6DataClassObjString = pSharedPref.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption

        for (obj in optionId6OptionHashSet.iterator())
        {
            shotTypeList.add(obj.title)
        }
    }*/

    private fun getAllShotType() {
        shotTypeList = ArrayList<String>()
        val optionId6DataClassObjString = pSharedPref.getString("optionId6DataClassObjString", "optionId6DataClassObjStringNotExist")
        val type: Type? = object : TypeToken<OptionId6DataClass>() {}.type
        val optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        val optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption

        Log.i("TAG", "getAllShotType: aisse "+optionId6OptionHashSet.size)

        var i = 0;
        while (i < (optionId6OptionHashSet.size + 1)){
            optionId6OptionHashSet.forEach {
                if (it.sequenceNum == i){
                    shotTypeList.add(it.title)
                }
            }
            i++
        }
        Log.i("TAG", "getAllShotType: andd "+shotTypeList)
    }


    private fun returnResultsBack() {
        val intent = Intent("custom-event-name")
        intent.putExtra("selectedItem", selectedItem)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    private fun setWindowFlag(activity: Activity, on: Boolean) {
        val win = activity.window
        val winParams = win.attributes
        if (on) {
            winParams.flags = winParams.flags or WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
        } else {
            winParams.flags =
                winParams.flags and WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS.inv()
        }
        win.attributes = winParams
    }

    override fun onBackPressed() {
        // Fade-Out Animation the Semi-Transparent Black Background
        // Close PickerView with slide down animation
        val alpha = 85 //between 0-255
        val alphaColor = ColorUtils.setAlphaComponent(Color.TRANSPARENT, alpha)
        val colorAnimation = ValueAnimator.ofObject(ArgbEvaluator(), alphaColor, Color.TRANSPARENT)
        colorAnimation.duration = 500 // milliseconds
        colorAnimation.addUpdateListener { animator -> binding.pickerviewtransbg.setBackgroundColor(Color.TRANSPARENT) }
        slideDown(binding.pickerviewbg)
        colorAnimation.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                finish()
                overridePendingTransition(0, 0)
            }
        })
        colorAnimation.start()
    }


    // Slide the view from its current position to below itself
    private fun slideUp(view: View) {
        ObjectAnimator.ofFloat(view, "translationY", 0f).apply {
            duration = 600
            start()
        }
    }

    // Slide the view from below itself to the current position
    private fun slideDown(view: View) {
        val mDisplay = windowManager.defaultDisplay
        val mDisplaySize = Point()
        mDisplay.getSize(mDisplaySize)
        val maxY = mDisplaySize.y
        val animation = ObjectAnimator.ofFloat(view, "translationY", maxY.toFloat())
        animation.duration = 600
        animation.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        slideUp(binding.pickerviewbg)
    }

}
