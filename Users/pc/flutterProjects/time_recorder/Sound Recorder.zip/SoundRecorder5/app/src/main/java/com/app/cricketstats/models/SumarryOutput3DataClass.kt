package com.app.cricketstats.models

data class SumarryOutput3DataClass(val sequenceNum: Int, val output3: String,val type: String )