package com.app.cricketstats.activity

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.cricketstats.R
import com.app.cricketstats.adapters.BattingSessionAdapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.ActivityBattingSessionBinding
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.models.ViewListingModel
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type
import java.util.*

class BattingSessionActivity : AppCompatActivity() {

    lateinit var binding: ActivityBattingSessionBinding

    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var bowlingDataList = ArrayList<ViewListingModel>()
    var isOutputTwo: Boolean = false
    var isBowling: Boolean = false
    lateinit var battingSessionAdapter : BattingSessionAdapter
    private var optionId6OptionTitleArray = ArrayList<String>()
    private lateinit var optionId6ArrayAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  setContentView(R.layout.activity_batting_session)

        binding = ActivityBattingSessionBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        pSharedPref = getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

    }

    private fun setUiAction() {
        initializeAgeGroupDropdown()
        InitializeShotTypeDropdown()

        val callFor = intent.getStringExtra("call_for")
        if(callFor.equals("batting")){
            if (appPreferences.isImperial == false){
                binding.companyNameText.text = getString(R.string.batting_session_summary)
                binding.speedHeadingTv.text = getString(R.string.bat_swing_speed_km_hr)
            }else{
                binding.companyNameText.text = getString(R.string.batting_session_summary)
                binding.speedHeadingTv.text = getString(R.string.bat_swing_speed_mile_hr)
            }
            isOutputTwo = true
            viewListingResult()
        }else if(callFor.equals("aerial")){
            if (appPreferences.isImperial == false){
                binding.companyNameText.text = getString(R.string.areial_travel_distance)
                binding.speedHeadingTv.text = getString(R.string.aerial_travel_distnace_meters)
            }else{
                binding.companyNameText.text = getString(R.string.areial_travel_distance)
                binding.speedHeadingTv.text = getString(R.string.aerial_travel_distance_yard)
            }
            isOutputTwo = false
            viewListingResult()
        }else if(callFor.equals("bowling")){
            isBowling = true
            if (appPreferences.isImperial == false){
                binding.companyNameText.text = getString(R.string.ball_exit_session_summry)
                binding.speedHeadingTv.text = getString(R.string.ball_exit_speed_km_hr)
            }else{
                binding.companyNameText.text = getString(R.string.ball_exit_session_summry)
                binding.speedHeadingTv.text = getString(R.string.ball_exit_speed_mile_hr)
            }
            viewListingThreeResult()
        }

    }


    private fun InitializeShotTypeDropdown() {
        var optionId6DataClassObjString = pSharedPref?.getString(
                "optionId6DataClassObjString",
                "optionId6DataClassObjStringNotExist"
        )
        var type: Type? = object : TypeToken<OptionId6DataClass>() {}.getType()
        var optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(
                optionId6DataClassObjString,
                type
        )
        var optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        optionId6OptionHashSet.forEach {
            optionId6OptionTitleArray.add(it.title)
        }

        optionId6ArrayAdapter = ArrayAdapter(
                this!!,
                R.layout.spinner_item,
                optionId6OptionTitleArray
        )
        optionId6ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.materialTypeSpinner.adapter = optionId6ArrayAdapter
    }

    fun initializeAgeGroupDropdown(){
        val adapter = ArrayAdapter.createFromResource(this, R.array.age_array, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.ageSpinner.adapter = adapter

        appPreferences = AppPreferences()
        appPreferences.init(this)

        bowlingDataList = ArrayList()

        binding.recyclerview.layoutManager = LinearLayoutManager(this)

        binding.backBtn.setOnClickListener {
            finish()
        }


        binding.materialTypeSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                (parent!!.getChildAt(0) as TextView).setTextColor(Color.WHITE)
                    if(!isBowling){
                        viewListingResult()
                    }else{
                        viewListingThreeResult()
                    }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })


        binding.ageSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                (parent!!.getChildAt(0) as TextView).setTextColor(Color.WHITE)
                if(!isBowling){
                    viewListingResult()
                }else{
                    viewListingThreeResult()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

    }


    private fun viewListingResult() {
        bowlingDataList.clear()
        binding.cpCardview.visibility = View.VISIBLE
        var map = HashMap<String,Any>()
        map.put("selectedMaterial", binding.materialTypeSpinner.selectedItem.toString())
        map.put("isOutputTwo", isOutputTwo)
        map.put("selectedAgeGroup", binding.ageSpinner.selectedItem.toString())
        map.put("userId", appPreferences.uuid)
        map.put("isImperial", appPreferences.isImperial)
        System.out.println("input_map_is "+map.toString())
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.viewListingOne(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    binding.cpCardview.visibility = View.GONE
                    val res = Gson().toJson(response.body())
                    val mainObject = JSONObject(res)
                    Log.d("VIEW_LISTING_ONE", mainObject.toString())
                    if (mainObject.getBoolean("success")) {

                        for (i in 0..mainObject.getJSONArray("data").length() - 1){
                            val jsonObj = mainObject.getJSONArray("data").getJSONObject(i)
                            bowlingDataList.add(ViewListingModel(jsonObj.getString("name"), jsonObj.getString("output"), ""))
                        }
                        battingSessionAdapter = BattingSessionAdapter(bowlingDataList, this@BattingSessionActivity)
                        binding.recyclerview.adapter = battingSessionAdapter

                    } else {
                        Toast.makeText(
                            this@BattingSessionActivity, mainObject.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.i("TAG", "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                call.cancel()
                binding.cpCardview.visibility = View.GONE
                Log.e("VIEW_LISTING onFailure", throwable.toString())
            }
        })
    }

    private fun viewListingThreeResult() {
        bowlingDataList.clear()
        binding.cpCardview.visibility = View.VISIBLE
        var map = HashMap<String,Any>()
        map.put("selectedMaterial", binding.materialTypeSpinner.selectedItem.toString())
        map.put("selectedAgeGroup", "")
        map.put("userId", appPreferences.uuid)
        map.put("isImperial", appPreferences.isImperial)
        System.out.println("input_map_is 3 "+map.toString())
        val call = ApiClient().getClient(this)!!.create(ApiInterface::class.java)
        call.viewListingThree(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    binding.cpCardview.visibility = View.GONE
                    val res = Gson().toJson(response.body())
                    val mainObject = JSONObject(res)
                    Log.d("VIEW_LISTING 3 response", mainObject.toString())
                    if (mainObject.getBoolean("success")) {

                        for (i in 0..mainObject.getJSONArray("data").length() - 1){
                            val jsonObj = mainObject.getJSONArray("data").getJSONObject(i)
                            bowlingDataList.add(ViewListingModel(jsonObj.getString("name"), jsonObj.getString("output"), ""))
                        }
                        battingSessionAdapter = BattingSessionAdapter(bowlingDataList, this@BattingSessionActivity)
                        binding.recyclerview.adapter = battingSessionAdapter

                    } else {
                        Toast.makeText(
                            this@BattingSessionActivity, mainObject.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.i("TAG", "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                call.cancel()
                binding.cpCardview.visibility = View.GONE
                Log.e("VIEW_LISTING onFailure", throwable.toString())
            }
        })
    }
}