package com.app.cricketstats.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {
    lateinit var binding: ActivitySplashBinding
    lateinit var user: AppPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        user = AppPreferences()
        user.init(this)

        isLogedIn()

    }



    private fun isLogedIn() {
         if (user.isLogin)
         {
             val intent = Intent(this,MainActivity::class.java)
             startActivity(intent)
             finish()
         }else{
             val intent = Intent(this,WelcomeActivity::class.java)
             startActivity(intent)
             finish()
         }
    }

    companion object {
        private const val TAG = "SplashActivity"
    }
}