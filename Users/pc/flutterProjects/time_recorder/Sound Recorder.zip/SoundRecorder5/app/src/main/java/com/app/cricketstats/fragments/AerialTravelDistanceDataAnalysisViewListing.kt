package com.app.cricketstats.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
  import com.app.cricketstats.R
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.adapters.BattingDataAnalysisViewListingAdapter
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentAerialTravelDistanceDataAnalysisViewListingBinding
import com.app.cricketstats.models.OptionId6DataClass
import com.app.cricketstats.models.Output2ViewListingDataClass
import com.app.cricketstats.network.ApiClient
import com.app.cricketstats.network.ApiInterface
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.lang.reflect.Type

class AerialTravelDistanceDataAnalysisViewListing : Fragment(), View.OnClickListener {
     lateinit var binding: FragmentAerialTravelDistanceDataAnalysisViewListingBinding
    var mContext: Context? = null
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    private var optionId6OptionTitleArray = ArrayList<String>()
    private lateinit var optionId6ArrayAdapter: ArrayAdapter<String>
    var list  = ArrayList<Output2ViewListingDataClass>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentAerialTravelDistanceDataAnalysisViewListingBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {

        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)
        binding.backBtn.setOnClickListener(this)
        InitializeShotTypeDropdown()
        callViewListingApi()

        binding.materialTypeDropdown.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                callViewListingApi()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        setUnit()
        /*setPageTitleTextSize()*/
    }

   /* private fun setPageTitleTextSize() {
        var textSize = binding.companyNameText.text.length
        if (textSize > 24  && textSize < 33){
            binding.companyNameText.setTextSize(TypedValue.COMPLEX_UNIT_DIP,15f);
        }else if (textSize > 30){
            binding.companyNameText.setTextSize(TypedValue.COMPLEX_UNIT_DIP,14f);
        }
    }*/

    private fun setUnit() {
        if (appPreferences.isImperial == false){
            binding.aerialTravelDistanceTitleTv.text = getString(R.string.aerial_travel_distnace_meters)
        }else {
            binding.aerialTravelDistanceTitleTv.text = getString(R.string.aerial_travel_distance_yard)
        }
    }

    private fun callViewListingApi() {
        binding.cpCardview.visibility = View.VISIBLE
        var map = HashMap<String,Any>()
        map["selectedMaterial"] = binding.materialTypeDropdown.selectedItem.toString()
        map["isOutputTwo"] = false
        map["selectedAgeGroup"] = ""
        map["userId"] = appPreferences.uuid
        map["isImperial"] = appPreferences.isImperial
        Log.i(Companion.TAG, "callApiTogetViewListingResultForOutput1: rljrf $map")
        val call = ApiClient().getClient(mContext!!)!!.create(ApiInterface::class.java)
        call.viewListingOne(map, appPreferences.token).enqueue(object : retrofit2.Callback<Any> {
            override fun onResponse(call: Call<Any>, response: Response<Any>) {
                try {
                    if (response.body() == null) {
                        var errorText = response.errorBody().toString()
                        Log.i(Companion.TAG, "onResponse: rjerrkk $errorText")
                    }
                    val res = Gson().toJson(response.body())
                    val mainObject = JSONObject(res)
                    Log.d("VIEW_LISTING_ONE", mainObject.toString())
                    if (mainObject.getBoolean("success")) {
                        binding.cpCardview.visibility = View.GONE
                        list.clear()
                        var i = 0
                        while (i < mainObject.getJSONArray("data").length() - 1) {
                            val obj = mainObject.getJSONArray("data").getJSONObject(i)
                            list.add(Output2ViewListingDataClass(obj.opt("userId") as String, obj.opt("output") as String, obj.opt("outputDate") as String , obj.opt("name") as String))
                            i++
                        }
                        val battingDataAnalysisViewListingAdapter = BattingDataAnalysisViewListingAdapter(list)
                        binding.recyclerview.adapter = battingDataAnalysisViewListingAdapter
                    } else {
                        binding.cpCardview.visibility = View.GONE
                        Toast.makeText(
                            mContext,
                            "problem is " + mainObject.getString("message"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {

                    binding.cpCardview.visibility = View.GONE
                    Log.i( TAG, "onResponse: exception is her " + e.message.toString())
                    call.cancel()
                }
            }

            override fun onFailure(call: Call<Any>, throwable: Throwable) {
                binding.cpCardview.visibility = View.GONE
                call.cancel()
                Log.e("onFailure  ->", throwable.toString())
            }
        })
    }



    private fun InitializeShotTypeDropdown() {
        var optionId6DataClassObjString = pSharedPref?.getString(
            "optionId6DataClassObjString",
            "optionId6DataClassObjStringNotExist"
        )
        var type: Type? = object : TypeToken<OptionId6DataClass>() {}.getType()
        var optionId6DataClassObj: OptionId6DataClass = Gson().fromJson(optionId6DataClassObjString, type)
        var optionId6OptionHashSet = optionId6DataClassObj.hashSetOfOption
        optionId6OptionHashSet.forEach {
            optionId6OptionTitleArray.add(it.title)
        }

        optionId6ArrayAdapter = ArrayAdapter(
            mContext!!,
            R.layout.spinner_item,
            optionId6OptionTitleArray
        )
        optionId6ArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.materialTypeDropdown.adapter = optionId6ArrayAdapter
    }


    companion object {
        private const val TAG = "AerialTravelDistanceDat"
    }

    override fun onClick(v: View?) {
        when(v) {
            binding.backBtn -> {
                (activity as MainActivity).popFragments()
                /*requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, StatisticsFragment(), "statistics_fragment").commit();*/
            }
        }
    }
}