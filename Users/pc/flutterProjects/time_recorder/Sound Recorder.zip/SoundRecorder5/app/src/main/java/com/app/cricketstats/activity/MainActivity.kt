package com.app.cricketstats.activity

import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.app.cricketstats.R
import com.app.cricketstats.databinding.ActivityMainBinding
import com.app.cricketstats.fragments.*
import com.app.cricketstats.viewmodels.MainViewModel
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.*


class MainActivity : AppCompatActivity(){
    lateinit var binding: ActivityMainBinding
    var dataRecorded = false
    var isOutput3Visible = false
    private var mStacks = HashMap<String, Stack<Fragment>>()
    val TAB_DATA_ANALYSIS = "tab_data_analysis"
    val TAB_HOME = "tab_home"
    val TAB_PROFILE = "tab_profile"
    private var mCurrentTab: String? = null
    lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        /*setUiAction()*/


        binding.navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        viewModel = MainViewModel()


        mStacks = HashMap()
        mStacks!![TAB_DATA_ANALYSIS] = Stack()
        mStacks!![TAB_HOME] = Stack()
        mStacks!![TAB_PROFILE] = Stack()

        binding.navigation.selectedItemId = R.id.home_icon
    }


    private val mOnNavigationItemSelectedListener =
        BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.data_analysis_icon -> {
                    selectedTab(TAB_DATA_ANALYSIS)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.home_icon -> {
                    selectedTab(TAB_HOME)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.profile_icon -> {
                    selectedTab(TAB_PROFILE)
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }

    private fun selectedTab(tabId: String) {
        mCurrentTab = tabId
        if (mStacks!![tabId]!!.size == 0) {
            /*
             *    First time this tab is selected. So add first fragment of that tab.
             *    Dont need animation, so that argument is false.
             *    We are adding a new fragment which is not present in stack. So add to stack is true.
             */
            if (tabId == TAB_DATA_ANALYSIS) {
                pushFragments(tabId, DataAnalysisFragment(), true)
            } else if (tabId == TAB_HOME) {
                pushFragments(tabId, HomeFragment(), true)
            } else if (tabId == TAB_PROFILE) {
                pushFragments(tabId, ProfileFragment(), true)
            }
        } else {
            /*
             *    We are switching tabs, and target tab is already has atleast one fragment.
             *    No need of animation, no need of stack pushing. Just show the target fragment
             */
            pushFragments(tabId, mStacks!![tabId]!!.lastElement(), false)
        }
    }

    fun pushFragments(tag: String?, fragment: Fragment?, shouldAdd: Boolean) {
        if (shouldAdd) mStacks!![tag!!]!!.push(fragment)
        val manager = supportFragmentManager
        val ft = manager.beginTransaction()
        ft.replace(R.id.fragment_container, fragment!!)
        ft.commit()
    }




    override fun onBackPressed() {

        if (mStacks!![mCurrentTab!!]!!.size == 1) {
            // We are already showing first fragment of current tab, so when back pressed, we will finish this activity..
            finish()
            return
        }

        /* Goto previous fragment in navigation stack of this tab */

        /* Goto previous fragment in navigation stack of this tab */
        popFragments()
    }

    fun popFragments() {
        /*
         *    Select the second last fragment in current tab's stack..
         *    which will be shown after the fragment transaction given below
         */
        val fragment = mStacks!![mCurrentTab!!]!!.elementAt(mStacks!![mCurrentTab!!]!!.size - 2)
       if (fragment.toString().contains("HomeFragment"))
       {
           if (dataRecorded){
               getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, UploadDataSingleUserFragment()).commit()
               dataRecorded = false
           }
       }
        /*pop current fragment from stack.. */
        mStacks!![mCurrentTab!!]!!.pop()

        /* We have the target fragment in hand.. Just show it.. Show a standard navigation animation*/
        val manager = supportFragmentManager
        val ft = manager.beginTransaction()
        ft.replace(R.id.fragment_container, fragment)
        ft.commit()
    }



    companion object {
        private const val TAG = "MainActivity"
    }


}