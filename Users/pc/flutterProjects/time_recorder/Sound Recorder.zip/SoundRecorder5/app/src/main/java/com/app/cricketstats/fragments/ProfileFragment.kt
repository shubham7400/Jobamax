package com.app.cricketstats.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.app.cricketstats.activity.MainActivity
import com.app.cricketstats.activity.WebViewActivity
import com.app.cricketstats.activity.WelcomeActivity
import com.app.cricketstats.config.AppPreferences
import com.app.cricketstats.databinding.FragmentProfileBinding
import java.util.*


class ProfileFragment : Fragment(), View.OnClickListener {
    lateinit var binding: FragmentProfileBinding
    var pSharedPref: SharedPreferences? = null
    lateinit var appPreferences: AppPreferences
    var mContext: Context? = null


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)

        mContext = requireContext()
        pSharedPref = mContext!!.getSharedPreferences("MyOutputs", Context.MODE_PRIVATE)

        setUiAction()

        return binding.getRoot()
    }

    private fun setUiAction() {
        appPreferences = AppPreferences()
        appPreferences.init(mContext!!)

        if (appPreferences.profileUrl != null && appPreferences.profileUrl != ""){
            Log.i(Companion.TAG, "setUiAction: ddddf " + appPreferences.profileUrl)
            DownloadImageFromInternet(binding.roundedimag).execute(appPreferences.profileUrl)
        }

        binding.userName.text = appPreferences.name


        binding.howToUseAppTv.text = pSharedPref!!.getString(
            "howToUseAppUrlTextString",
            "howToUseAppUrlTextStringNotExist"
        ).toString().replace("\"", "")
        binding.howToUseAppLayout.setOnClickListener(this)
        binding.logoutBtn.setOnClickListener(this)
        binding.profileLayout.setOnClickListener(this)

    }



    private fun logout() {
        appPreferences.email = ""
        appPreferences.token = ""
        appPreferences.uuid = ""
        appPreferences.isLogin = false
        mContext!!.startActivity(Intent(mContext, WelcomeActivity::class.java))
        requireActivity().finish()


       /* val dialog = Dialog(mContext!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.alert_dialog_for_yes_and_no)
        val text = dialog.findViewById<TextView>(R.id.cp_title) as TextView
        text.text = "do you want ot logout?"
        val dialogButtonOk: Button = dialog.findViewById<Button>(R.id.alert_ok_btn)
        dialogButtonOk.setOnClickListener  {
            appPreferences.email = ""
            appPreferences.token = ""
            appPreferences.uuid = ""
            appPreferences.isLogin = false
            mContext!!.startActivity(Intent(mContext, WelcomeActivity::class.java))
            requireActivity().finish()
            dialog.dismiss()
        }
        val dialogButtonNo: Button = dialog.findViewById<Button>(R.id.alert_no_btn)
        dialogButtonNo.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()*/
    }

    override fun onClick(v: View?) {
         when(v) {
             binding.howToUseAppLayout -> {
                 val howToUseAppUrl = pSharedPref!!.getString(
                     "howToUseAppUrlString",
                     "howToUseAppUrlStringNotExist"
                 ).toString().replace("\"", "")
                 val intent = Intent(mContext, WebViewActivity::class.java)
                 intent.putExtra("url", howToUseAppUrl)
                 startActivity(intent)
             }
             binding.logoutBtn -> {
                 logout()
             }
             binding.profileLayout -> {
                 (activity as MainActivity) .pushFragments((activity as MainActivity).TAB_PROFILE, EditProfileFragment(),true)

                /* requireActivity().getSupportFragmentManager().beginTransaction().replace(
                     R.id.fragment_container,
                     EditProfileFragment()*//*, "edit_profile_fragment"*//*
                 ).addToBackStack("tag").commit();*/
             }
         }
    }

    private inner class DownloadImageFromInternet(var imageView: ImageView) : AsyncTask<String, Void, Bitmap?>() {
        override fun doInBackground(vararg urls: String): Bitmap? {
            val imageURL = urls[0]
            var image: Bitmap? = null
            try {
                val `in` = java.net.URL(imageURL).openStream()
                image = BitmapFactory.decodeStream(`in`)
            }
            catch (e: Exception) {
                Log.e("Error Message", e.message.toString())
                e.printStackTrace()
            }
            return image
        }
        override fun onPostExecute(result: Bitmap?) {
            imageView.setImageBitmap(result)
        }
    }

    companion object {
        private const val TAG = "ProfileFragment"
    }

}